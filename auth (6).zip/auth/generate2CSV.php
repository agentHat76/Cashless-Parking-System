<?php
require_once 'Resource/database.php';
require_once 'Resource/session.php';

$date = date('Y');

//  HTTP CSV HEADERS
header("Content-Type: application/octet-stream");
header("Content-Transfer-Encoding: Binary");
header("Content-disposition: attachment; filename=\"export".$date.".csv\"");
 
//  GET USERS FROM DATABASE + DIRECT OUTPUT
 

echo implode(",", [
    'Transaction_id', 'Name', 'Transaction Date', 'Amount', 'Transaction Type']);
echo "\r\n";

$stmt = $db->prepare("SELECT * FROM transaction LEFT JOIN users ON transaction.user_id = users.id WHERE YEAR(transaction_date) = YEAR(now())
");
$stmt->execute();
while ($row = $stmt->fetch(PDO::FETCH_NAMED)) {
    $name = $row['firstname']." ".$row['lastname'];
    echo implode(",", [
        $row['Transaction_id'], $name, $row['transaction_date'], $row['amount'],$row['transaction_type']]);

    echo "\r\n";
}



?>