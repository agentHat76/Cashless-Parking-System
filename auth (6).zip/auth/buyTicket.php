<?php
$page_title = "Buy Ticket Page";
include_once 'partials/header.php';
include_once 'partials/parseProfile.php';
include_once 'partials/parseTransaction.php';
if(isset($_POST['exitingCard'])){
    echo '<form onsubmit="return confirm('.'Do you really want to submit the form?'.');">';
}

?>

<main style="padding: 20px;">
    <div>
    <section class="container">
    <?php if(!isset($_SESSION['username'])): ?>
        <p class="lead">You are not authorized to view this page <a href="login.php">Login</a>
        Not yet a member? <a href="signup.php">Signup</a></p>

    <?php else: ?>
        <div class="">
        <?php if(isset($result)) echo $result; ?>
        </div>
        <div class="card mt-3 mb-3 text-center">
            <div class="card-header"><h2>Information</h2></div>
            <div class="card-body">
            <h5>Segi College Subang Jaya</h5>
            <h5>1 Day (6am - 9pm)</h5>
            <h2>
            The ticket price is RM2.00.
            </h2>
            </div>
            <div class="card-footer">
            <p>
                The Ticket valid for one day. 
                For the over night parking need management permission.
                Public holiday college will closed.
            </p>
        </div>
        </div>
    <form id="form4" action="" method="post">
    <div class="mt-4 border border-info rounded-4 p-5">
    <div class="display-3 text-center text-dark">
        <em>Buy Ticket</em>
    </div>
    <div class="form-group mt-5">
            <label for="nameField">Name</label>
            <input type="text" class="form-control" name="name" id="nameField" aria-describedby="nameHelp" placeholder="<?php if(isset($name)) echo $name; ?>">
        </div>
        <div class="form-group mt-2">
            <label for="emailField">Email</label>
            <input type="text" class="form-control" name="email" id="emailField" aria-describedby="emailHelp" placeholder="<?php if(isset($email)) echo $email; ?>">
        </div>
        <div class="form-group mt-2">
            <label for="dateField">Date</label>
            <input type="text" class="form-control" name="date_of_purchase" id="date_of_purchaseField" aria-describedby="date_of_purchaseHelp" placeholder="<?php echo date("d/m/Y") ?>">
        </div>
        <div class="form-group mt-2">
            <button type="button" class="btn btn-primary w-100 p-3 mb-3 text-center flex-fill" name="DEBIT_CARD" value="DEBIT_CARD" id="debit-card" data-bs-toggle="modal" data-bs-target="#exampleModal">CREDIT / DEBIT CARD</button>
            <button type="button" class="btn btn-light w-100 p-3 mb-3 text-center flex-fill" name="ONLINE_BANKING" value="ONLINE_BANKING" id="online-banking" data-bs-toggle="modal" data-bs-target="#exampleModal2">ONLINE BANKING</button>
            <button type="button" class="btn btn-info w-100 p-3 mb-3 text-center flex-fill" name="E-WALLET" value="E-WALLET" id="e-wallet" data-bs-toggle="modal" data-bs-target="#exampleModal3">E-WALLET</button>
            
        </div>
        </div>
        

<!-- Modal Credit / Debit Card -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel1" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">CREDIT CARD</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <!-- here put the form -->
        <!-- old card -->
        <div class="card shadow">
                            <div class="card-header">
                                <label>Existing Card</label>
                            </div>
        <?php
                    $id = $_SESSION['id'];
                    $query = "SELECT * FROM bank INNER JOIN users ON bank.user_id = users.id WHERE users.id = :id AND bank.status=:Active ORDER BY bank_id DESC";
                    $statement = $db->prepare($query);
                    $statement->execute(array(':id'=>$id, ':Active'=>"Active"));

                    $result = $statement->fetchAll(PDO::FETCH_OBJ); //PDO::FETCH_ASSOC
                    if($result){

                        foreach($result as $row)
                        { 
                            
                                $cardnumber = '**** **** **** ' .$row->card_number_4;
                                $date =  date("m/Y", strtotime($row->valid_date));

                        ?>
                        
                            <div class="card-body">
                            <div class="d-flex flex-wrap w-100 justify-content-between">
                            <div class="form-check">
                            <form id="form1" action="" method="post">
                            <input class="form-check-input" type="checkbox" name="exitingCard" value="" id="exitingCard" for="form1" onchange="if(confirm('Are You Confirm The Payment?')){this.form.submit();}else {this.checked = false;}">                         
                            </form>
                            </div>
                            <h6 id="idea-title" class="mb-1 font-weight-bold text-primary"><?= $row->bank_name ?></h6>
                            <label class="mb-1 font-weight-regular text-dark"  for="exitingCard"><?= $cardnumber ?></label>
                            <span id="submission-date" class="mb-1 small text-gray-600"><?= $date ?></span>
                            </div>
                            </div>
                        

                        <?php

                        }
                    }else {
                        ?>
                        <!-- list item - single idea -->
                            <div class="card shadow mb-4 idea">
                                <div class="card-body">
                                    <h5>No Records</h5>
                                </div>
                            </div>
                            <?php
                    }
        ?>
        </div>
        <!-- new card -->

        <hr class="border border-dark border-2 opacity-50">
        
        <label class="opacity-75">Card Details</label>
        <form id="form2" action="" method="post">
        <div class="form-group">
        
        <!-- ask bank name -->
    
        <label for="bankName">BANK</label>
            <select id="bankName" class="form-control" name="bankName">
                 <option value="CIMB BANK" selected>CIMB BANK</option>
                 <option value="Maybank">Maybank</option>
                 <option value="RHB Now">RHB Now</option>
                 <option value="Ambank">Ambank</option>
                 <option value="MyBSN">MyBSN</option>
                 <option value="Bank Rakyat">Bank Rakyat</option>
                 <option value="UOB">UOB</option>
                 <option value="Affin Bank">Affin Bank</option>
                 <option value="Bank Islam">Bank Islam</option>
                 <option value="HSBC Online">HSBC Online</option>
                 <option value="Standard Chartered Bank">Standard Chartered Bank</option>
                 <option value="Kuwait Finance House">Kuwait Finance House</option>
                 <option value="Bank Muamalat">Bank Muamalat</option>
                 <option value="OCBC Online">OCBC Online</option>
                 <option value="Alliance Bank (Personal)">Alliance Bank (Personal)</option>
                 <option value="Hong Leong Connect">Hong Leong Connect</option>
                 <option value="Agrobank">Agrobank</option>
            </select>
        </div>
        <!-- ask card number -->
        <div class="form-group">
                <label for="cardNumber1Field">Card Number</label>
                <div class="d-flex justify-content-evently">
                <input type="number" pattern="[0-9]*" maxlength="4" class="form-control mr-1" name="cardNumber1" id="cardNumber1Field" aria-describedby="cardNumber1Help" placeholder="" required>
                <input type="number" pattern="[0-9]*" maxlength="4"  class="form-control mr-1" name="cardNumber2" id="cardNumber2Field" aria-describedby="cardNumber2Help" placeholder="" required>
                <input type="number" pattern="[0-9]*" maxlength="4" class="form-control mr-1" name="cardNumber3" id="cardNumber3Field" aria-describedby="cardNumber1Help" placeholder="" required>
                <input type="number" pattern="[0-9]*" maxlength="4"  class="form-control" name="cardNumber4" id="cardNumber4Field" aria-describedby="cardNumber2Help" placeholder="" required>
                </div>
        </div>
        <!-- expiry date -->
        <div class="form-group">
                <label for="expiry1Field">Expiry Date and CSV </label>
                <div class="d-flex justify-content-evently">
                <input type="month"  class="form-control mr-1" name="expiry" id="expiry1Field" aria-describedby="expiry1Help" placeholder="" required>
                <input type="number" pattern="[0-9]*" maxlength="3"  class="form-control mr-1" name="csv" id="csvField" aria-describedby="csvHelp" placeholder="CSV" required>
                </div>
        </div>
        <div class="form-check">
        <input class="form-check-input" type="checkbox" value="saveCard" name="saveCard" id="invalidCheck2">
            <label class="form-check-label" for="invalidCheck2">
                Save Card?
            </label>
            <p>I acknowledge that my card information is saved securely on my CPS account and One Time Password (OTP) might not be required for future transactions on CPS.</p>
        </div>
        
        
        
        
        
                
        <!-- end -->
    
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" for="form2">Close</button>
        <button type="submit" class="btn btn-primary float-end" name="payNew">Purchase</button>
        </form>
      </div>
       
      
    </div>
  </div>
</div>

<!-- Modal Online Banking -->
<div class="modal fade" id="exampleModal2" tabindex="-1" aria-labelledby="exampleModalLabel2" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">ONLINE BANKING</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <!-- here put the form -->
        <!-- Bank List form -->

        <label class="opacity-75">Bank List</label>
        <form id="form2" action="" method="post">
        <div class="form-group">
        
        <!-- ask bank name -->
            <select id="bankName" class="form-control" name="bankName">
                 <option value="CIMB BANK" selected>CIMB BANK</option>
                 <option value="Maybank">Maybank</option>
                 <option value="RHB Now">RHB Now</option>
                 <option value="Ambank">Ambank</option>
                 <option value="MyBSN">MyBSN</option>
                 <option value="Bank Rakyat">Bank Rakyat</option>
                 <option value="UOB">UOB</option>
                 <option value="Affin Bank">Affin Bank</option>
                 <option value="Bank Islam">Bank Islam</option>
                 <option value="HSBC Online">HSBC Online</option>
                 <option value="Standard Chartered Bank">Standard Chartered Bank</option>
                 <option value="Kuwait Finance House">Kuwait Finance House</option>
                 <option value="Bank Muamalat">Bank Muamalat</option>
                 <option value="OCBC Online">OCBC Online</option>
                 <option value="Alliance Bank (Personal)">Alliance Bank (Personal)</option>
                 <option value="Hong Leong Connect">Hong Leong Connect</option>
                 <option value="Agrobank">Agrobank</option>
            </select>
        </div>
     <!-- end -->
    
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" for="form2">Close</button>
        <button type="submit" class="btn btn-primary float-end" name="payOnline" onclick="return confirm('Are You Confirm The Payment?')">Purchase</button>
        </form>
      </div>
       
      
    </div>
  </div>
</div>

<!-- Modal eWallet-->
<div class="modal fade" id="exampleModal3" tabindex="-1" aria-labelledby="exampleModalLabel3" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">E-WALLET</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <!-- here put the form -->
        <!-- Bank List form -->

        <label class="opacity-75">eWallet List</label>
        <form id="form2" action="" method="post">
        <div class="form-group">
        
        <!-- ask bank name -->
            <select id="ewallet" class="form-control" name="ewallet">
                 <option value="Touch 'n Go eWallet" selected>Touch 'n Go eWallet</option>
                 <option value="PayPal">PayPal</option>
                 <option value="Apple Pay">Apple Pay</option>
                 <option value="BigPay">BigPay</option>
                 <option value="Alipay">Alipay</option>
                 <option value="Lazada Wallet">Lazada Wallet</option>
                 <option value="Google Pay">Google Pay</option>
                 <option value="MAE">MAE</option>
                 <option value="Bank Islam">Bank Islam</option>
                 <option value="Zapp">Zapp</option>>
            </select>
        </div>
     <!-- end -->
                    
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" for="form2">Close</button>
        <button type="submit" class="btn btn-primary float-end" name="payEwallet" onclick="return confirm('Are You Confirm The Payment?')">Purchase</button>
        </form>
      </div>
       
      
    </div>
  </div>
</div>

</form>  
   

    <?php endif ?>


    </section>
    </div>

    <script>
        function myFunction() {
  // Get the checkbox
  var checkBox = document.getElementById("exitingCard");
  // Get the output text
  var text = document.getElementById("text");

  // If the checkbox is checked, display the output text
  if (checkBox.checked == true){
    text.style.display = "block";
  } else {
    text.style.display = "none";
  }
}
    </script>
    <script>
function validate(form) {

    // validation code here ...


    if(!valid) {
        alert('Please correct the errors in the form!');
        return false;
    }
    else {
        return confirm('Do you really want to submit the form?');
    }
}
</script>
<form onsubmit="return validate(this);">

   