<?php
$page_title = "Admin Transaction List Page";
include_once 'partials/adminHeader.php';
include_once 'resource/utilities.php';
include_once 'partials/parseAdminLogin.php';
?>

<main style="padding-top: 30px">
<!-- if admin not sign in it show message -->
<?php if(!isset($_SESSION['username'])): ?>

<p class="lead">You are currently not signin <a href="adminlogin.php">Login!</a>

<!-- if admin sign in ready it run below code -->

<?php else: ?>

<section class="mt-3 container-fluid">

<div class="card">
    <div class="card-header">
        <h1 class="text-center text-primary">Transaction  Details</h1>
    </div>
    <div class="card-body table-responsive">
        <table class="table table-bordered table-striped">
            <thead>
                <tr  class="text-center">
                    <th>ID</th>
                    <th>Full Name</th>
                    <th>Email</th>
                    <th>Amount</th>
                    <th>Type of Transaction</th>
                    <th>Date of Transaction</th>
                </tr>
            </thead>
            <tbody>
                <?php

                    $sort_option = "";
                    $thead = "Transaction_id";
                    if(isset($_GET['sort_alphabet'])){
                        if($_GET['sort_alphabet'] == "a-z")
                        {
                            $thead = "firstname";
                            $sort_option = "ASC";
                    
                        }
                        elseif($_GET['sort_alphabet'] == "z-a") 
                        {
                            $thead = "firstname";
                            $sort_option = "DESC";
                        }
                        elseif($_GET['sort_alphabet'] == "") 
                        {
                            $thead = "Transaction_id";
                            $sort_option = "ASC";
                        }
                    }

                    

                    $query = "SELECT * FROM Transaction INNER JOIN users ON transaction.user_id = users.id ORDER BY $thead $sort_option";
                    $statement = $db->prepare($query);
                    $statement->execute();

                    $result = $statement->fetchAll(PDO::FETCH_OBJ); //PDO::FETCH_ASSOC
                    if($result){

                        foreach($result as $row)
                        { 
                            
                                $name = $row->firstname . ' ' .$row->lastname;
                                $date =  date("d/m/Y", strtotime($row->transaction_date));
                            ?>
                            <tr  class="text-center">
                                <td><?= $row->Transaction_id ?></td>
                                <td><?= $name?></td>
                                <td><?= $row->email ?></td>
                                <td><?= $row->amount ?></td>
                                <td><?= $row->transaction_type ?></td>
                                <td><?= $date?></td>
                            </tr>
                            <?php

                        }

                    } else {
                        ?>
                        <tr>
                            <td colspan="5">No Record Found</td>
                        </tr>
                        <?php
                    }
                ?>
                
            </tbody>
            <tfoot>
            <div class="d-inline-flex">
            <p style="font-size:large;"><a href="adminTransaction.php" class="btn btn-outline-secondary mt-3 mr-3">Back</a></p>
            <p style="font-size:large;"><a href="generatePDF.php" class="btn btn-outline-secondary mt-3 mr-3" onclick="return confirm('Generate Report')">PDF</a></p>
            <p style="font-size:large;"><a href="generateCSV.php" class="btn btn-outline-secondary mt-3 mr-3" onclick="return confirm('Generate Report, Montly Sales')">Monthly Sales</a></p>
            <p style="font-size:large;"><a href="generate2CSV.php" class="btn btn-outline-secondary mt-3" onclick="return confirm('Generate Report, Yearly Sales')">Yearly Sales</a></p>
            </div>
            <form action="" method="GET">
            <div class="input-group mb-2">
                <select name="sort_alphabet" class="form-control">
                    <option value="" <?php if(isset($_GET['sort_alphabet']) && $_GET['sort_alphabet'] == ""){ echo "selected";}?>>--Select Option--</option>
                    <option value="a-z" <?php if(isset($_GET['sort_alphabet']) && $_GET['sort_alphabet'] == "a-z"){ echo "selected";}?>>A-Z (Ascending Order)</option>
                    <option value="z-a" <?php if(isset($_GET['sort_alphabet']) && $_GET['sort_alphabet'] == "z-a"){ echo "selected";}?>>Z_A (Descending Order)</option>
                </select>
                <button type="submit" class="input-group-text btn btn-primary" id="basic-addon2">Sort</button>
            </div>
        </form>
            </tfoot>

        </table>

    </div>
</div>

</section>


    

<?php endif ?>
</main>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</body>
</html>