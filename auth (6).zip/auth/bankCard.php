<?php
$page_title = "Account Page - Bank Card";
include_once 'partials/header.php';
if(isset($_POST['deleteButton'])){
  $bank_id = $_POST['deleteButton'];
  try{
    $sqlQuery = "DELETE FROM bank WHERE bank_id=:bank_id";
    $statement = $db->prepare($sqlQuery);
    $date = [
        ':bank_id' => $bank_id
    ];
    $sqlQuery_execute = $statement->execute($date);

    if($sqlQuery_execute)
    {
        $result = flashMessage("Deleted Successfully");
        echo "<meta http-equiv='refresh' content='2'>";
    } 
    else 
    {
        $result = flashMessage("Not Deleted");
        echo "<meta http-equiv='refresh' content='2'>";
    }


} catch (PDOException $e) {
    echo $e->getMessage();
}
}
?>


<main style="padding-top: 10px;">
    <div>
    <section>
        
        <!-- if not log in it show alert message -->
        <div style="margin-bottom: 25px;"></div>
        <?php if(!isset($_SESSION['username'])): ?>
        <p class="lead">You are not authorized to view this page <a href="login.php">Login</a>
        Not yet a member? <a href="signup.php">Signup</a></p>
        <?php else: ?>

<!-- if log in onto account, it below content             -->
<div class="container mt-3">

<!-- using bootstrap css design card -->
<div class="card mb-2">
<!-- card header -->
  <div class="card-header">
    <ul class="nav nav-tabs card-header-tabs">
      <li class="nav-item">
        <a class="nav-link active" href="profile.php">My Profile</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active text-bg-primary" aria-current="true" href="#">Banks & Cards </a>
      </li>
      <li class="nav-item">
        <a class="nav-link active" href="myTransaction.php">My Purchase</a>
      </li>
    </ul>
  </div>
  <!-- card body -->
  <div>
  <?php if(isset($result)) echo $result; ?>
  <?php if(!empty($form_errors)) echo show_errors($form_errors); ?>
  </div>
  <div class="card-body table-responsive">
        <table class="table table-bordered table-hover shadow">
            <thead>
                <tr  class="text-center">
                    <th>Card Type.</th>
                    <th>Bank Name</th>
                    <th>Card Number</th>
                    <th>Valid Date</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $id = $_SESSION['id'];
                    $query = "SELECT * FROM bank INNER JOIN users ON bank.user_id = users.id WHERE users.id = :id ORDER BY bank_id DESC";
                    $statement = $db->prepare($query);
                    $statement->execute(array(':id'=>$id));

                    $result = $statement->fetchAll(PDO::FETCH_OBJ); //PDO::FETCH_ASSOC
                    if($result){

                        foreach($result as $row)
                        { 
                            
                                $cardnumber = $row->card_number_1 . ' ' .$row->card_number_2.' '.$row->card_number_3. ' ' .$row->card_number_4;
                                $date =  date("d/m/Y", strtotime($row->valid_date));
                            ?>
                            <tr  class="text-center">
                                <td><?= $row->card_type?></td>
                                <td><?= $row->bank_name?></td>
                                <td><?= $cardnumber ?></td>
                                <td><?= $row->valid_date ?></td>
                                <td><?= $row->status ?></td>
                                <td>
                                  <form action="" method="post">
                                  <button type="submit" name="deleteButton" class="btn text-bg-danger shadow" value="<?= $row->bank_id ?>" onclick="return confirm('Are you sure?')">Delete</button>
                                  </form>
                                </td>
                            </tr>
                            <?php

                        }

                    } else {
                        ?>
                        <tr>
                            <td colspan="6">No Record Found</td>
                        </tr>
                        <?php
                    }
                ?>
                
            </tbody>
  


</div>
            </section>
        <?php endif ?>
    </div>
</main>


<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</body>
</html>