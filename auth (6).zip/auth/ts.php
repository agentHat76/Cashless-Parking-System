<?php 
// Include QR code scanning library
require_once 'phpqrcode/qrlib.php';

// Include PHPMailer library
require_once 'phpmailer/PHPMailerAutoload.php';

// Set QR code image path
$qrCodeImagePath = 'qrcode.png';

// Scan QR code using PHP QR Code library
$qrCodeData = QRcode::text('Hello World');

// Send email notification using PHPMailer library
$mail = new PHPMailer;

$mail->setFrom('sender@example.com', 'Sender Name');
$mail->addAddress('recipient@example.com', 'Recipient Name');
$mail->Subject = 'QR Code Scanned';
$mail->Body = 'QR Code data: ' . $qrCodeData;

// Attach QR code image to email
$mail->addAttachment($qrCodeImagePath);

if (!$mail->send()) {
    echo 'Email could not be sent.';
    echo 'Mailer Error: ' . $mail->ErrorInfo;
} else {
    echo 'Email has been sent.';
}
?>