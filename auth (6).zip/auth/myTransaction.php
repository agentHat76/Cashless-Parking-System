<?php
$page_title = "Account Page - My Transaction";
include_once 'partials/header.php';
include_once 'partials/parseProfile.php';
?>


<main style="padding-top: 10px;">
    <div>
    <section>
        
        <!-- if not log in it show alert message -->
        <div style="margin-bottom: 25px;"></div>
        <?php if(!isset($_SESSION['username'])): ?>
        <p class="lead">You are not authorized to view this page <a href="login.php">Login</a>
        Not yet a member? <a href="signup.php">Signup</a></p>
        <?php else: ?>

<!-- if log in onto account, it below content             -->
<div class="container mt-3">

<!-- using bootstrap css design card -->
<div class="card mb-2">
<!-- card header -->
  <div class="card-header d-flex flex-wrap">
    <ul class="nav nav-tabs card-header-tabs">
      <li class="nav-item">
        <a class="nav-link active" href="profile.php">My Profile</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active" href="bankCard.php">Banks & Cards</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active text-bg-primary" aria-current="true" href="#">My Purchase</a>
      </li>
    </ul>
  </div>
  <!-- card body -->
  <div class="card-body table-responsive">
        <table class="table table-bordered shadow table-light table-hover">
            <thead>
                <tr  class="text-center">
                    <th>Ticket No.</th>
                    <th>Amount</th>
                    <th>Type</th>
                    <th>Date</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $id = $_SESSION['id'];

                    $query = "SELECT * FROM Transaction INNER JOIN users ON transaction.user_id = users.id WHERE users.id=:id ORDER BY Transaction_id DESC";
                    $statement = $db->prepare($query);
                    $statement->execute(array(':id'=>$id));

                    $result = $statement->fetchAll(PDO::FETCH_OBJ); //PDO::FETCH_ASSOC
                    if($result){

                        foreach($result as $row)
                        { 
                            
                                $name = $row->firstname . ' ' .$row->lastname;
                                $date =  date("Y/m/d", strtotime($row->transaction_date));
                                $encode_id = base64_encode("encodeuserid{$row->Transaction_id}");
                                if(strtotime($date) === strtotime('today'))
                                {
                                    $status = "Valid";
                                } else {
                                    $status = "No Valid";
                                }
                                
                            ?>
                          
                            <tr class="text-center">
                                <td><?= $row->Transaction_id ?></td>
                                <td>RM<?= $row->amount ?>.00</td>
                                <td><?= $row->transaction_type ?></td>
                                <td><?= $date?></td>
                                <td><?= $status?></td>
                                <td><a class="btn text-bg-info shadow" role="button" href="viewTicket.php?id=<?= $encode_id   ?>">View Ticket</a></td>
                                
                            </tr>
                            
                            <?php

                        }

                    } else {
                        ?>
                        <tr>
                            <td colspan="6">No Record Found</td>
                        </tr>
                        <?php
                    }
                ?>
                
            </tbody>



</div>
            </section>
        <?php endif ?>
    </div>
</main>


<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</body>
</html>