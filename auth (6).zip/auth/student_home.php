<?php
$page_title = "Homepage";
include_once 'partials/header.php';
include_once 'partials/parseActiveTicket.php';
include_once 'resource/utilities.php';
?>

<!-- padding for display within layout -->
<main style="padding-top: 70px; padding-left: 35px; padding-bottom: 40px;">

<!-- if user not login, it run below code. display alert message to login or signup -->
<?php if(!isset($_SESSION['username'])): ?>

<p class="lead">You are currently not signin <a href="login.php">Login</a> <br>Not yet a member? <a href="signup.php">Sign up</a> </p>

<!-- if user login successfully, it run below code. display ticket module and purchase module -->
<?php else: ?>
<!-- Ticket module -->
<div class="container-fluid d-sm-flex justify-content-sm-center text-center">
<div class="card rounded-5 p-3 shadow" style="width: 18rem;">
    <h2 class="card-title">Ticket</h2>
    <?php  echo "<img src='https://api.qrserver.com/v1/create-qr-code/?size=256x256&data=$qr_code' class='card-img-top shadow' alt='...''>"; ?>
    <div class="card-body">
    <div id="qrcode" ></div>
    
    <h5 class="card-title">Ticket No.: <?php if(isset($ticket_id)) echo $ticket_id; ?></h5>
    <p class="card-text">Ticket Type: Day Pass</p>
    <p href="#" class="d-block border rounded-2 text-danger">Valid Until: <?php 
        
        if (strtotime($expiration_day) === strtotime('today')) {
          echo $validUntil;
        } else {
          echo 'No valid';
        }
        
        ?></p>
    </div>
  </div>
  <div class="mb-5 mr-5"></div>

  <!-- Purchase ticket module -->

    <div class="card rounded-5 p-3 shadow" style="width: 18rem;">
    <h2 class="card-title">Purchase Ticket</h2>
    <img src="uploads/pngwing.com.png" class="card-img-top" alt="..." width="200" height="200">
    <div class="card-body">
    <div id="qrcode" ></div>
    
    <h5 class="card-title">Don't Have Ticket?</h5>
    <button class="btn btn-outline-success btn-block p-3" onclick="window.location.href = 'buyTicket.php';">Buy Ticket</button>
    </div>
    </div>  
</div>

    <?php endif ?>
</main>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</body>
</html>