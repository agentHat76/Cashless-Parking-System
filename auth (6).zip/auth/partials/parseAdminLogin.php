<?php  
include_once 'resource/session.php';
include_once 'resource/Database.php';
include_once 'resource/utilities.php';

if(isset($_POST['loginBtn'])){
    //array to hold errors
$form_errors = array();

//validates
$required_fields = array('username', 'password');
$form_errors = array_merge($form_errors, check_empty_fields($required_fields));

if(empty($form_errors)){
    //collect form data
    $user = $_POST['username'];
    $password = $_POST['password'];

    isset($_POST['remember']) ? $remember = $_POST['remember'] : $remember = "";

    //check if user exits in the database
    $sqlQuery = "SELECT * FROM Admin WHERE username = :username";
    $statement = $db->prepare($sqlQuery);
    $statement->execute(array(':username' => $user));
    if($statement->rowCount() == 1){
    while($row = $statement->fetch()){
        $id = $row['admin_id'];
        $hashed_password = $row['password'];
        $username = $row['username'];
        $department = $row['department'];
        $decryptPassword = decryptFunction($hashed_password);

        if($password == $decryptPassword){
            $_SESSION['admin_id'] = $id;
            $_SESSION['username'] = $username;
            $_SESSION['department'] = $department;

            $fingerprint = md5($_SERVER["REMOTE_ADDR"].$_SERVER['HTTP_USER_AGENT']);
            $_SESSION['last_active'] = time();
            $_SESSION['fingerprint'] = $fingerprint;

            if($remember == "yes"){
                rememberMe($id);
            }

            $result = flashMessage("Login Successfully", "Pass");
            header("refresh:1; admin.php");
        }else {
            $result = flashMessage("Invalid Username or Password");
        }
    }
}else {
    $result = flashMessage("Invalid Username");
}


} else {
    if(count($form_errors) == 1){
        $result =  flashMessage("There was 1 error in the form<br>");
    }else{
        $result =  flashMessage(" There are " .count($form_errors)." error in the form<br>");
    }
}
}
