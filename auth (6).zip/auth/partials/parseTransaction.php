<?php
include_once 'resource/Database.php';
include_once 'resource/utilities.php';
include_once 'resource/session.php';
include_once 'partials/parseProfile.php';
ini_set('display_errors','Off');
ini_set('error_reporting', E_ALL );
define('WP_DEBUG', false);
define('WP_DEBUG_DISPLAY', false);


if((isset($_SESSION['id']) || isset($_GET['user_identity'])) && isset($_POST['payNew']) || isset($_POST['exitingCard']) || isset($_POST['DEBIT_CARD']) || isset($_POST['payOnline']) || isset($_POST['payEwallet'])){

    if(isset($_GET['user_identity'])){
        $url_encoded_id = $_GET['user_identity'];
        $decode_id = base64_decode($url_encoded_id);
        $user_id_array = explode("encodeuserid", $decode_id);
        $id = $user_id_array[1];
    }else{
    $id = $_SESSION['id'];
    }

    $sqlQuery = "SELECT * FROM ticket";
    $statement = $db->prepare($sqlQuery);
    $statement->execute();

    while($rs = $statement->fetch()){
        $ticket_id2 = $rs['ticket_id'];
        $price2 = $rs['price'];
    }

    if(isset($_POST['payNew']) || isset($_POST['exitingCard']))
    $type = "Credit / Debit Card";

    if(isset($_POST['payOnline']))
    $type = "ONLINE_BANKING";
    
    if(isset($_POST['payEwallet']))
    $type = $_POST['ewallet'];

// Get user input
$user_id = $id;
$ticket_id = $ticket_id2;
$price = $price2;
$transaction_type = $type;
$date_of_purchase = date("Y-m-d");
$expiration_time = date("Y-m-d"); 
// get bank input
if( isset($_POST['payNew'])){
$bankName = $_POST['bankName'];
$cardNumber1 = $_POST['cardNumber1'];
$cardNumber2 = $_POST['cardNumber2'];
$cardNumber3 = $_POST['cardNumber3'];
$cardNumber4 = $_POST['cardNumber4'];
$expiry = date('Y/m/d', strtotime($_POST['expiry']));
if($expiry < date("Y/m/d")){
    $status = "No Active";
}else{
    $status = "Active";
}
}


// $expiration_time = date("Y-m-d", time() + 86400);

try{
    if ( isset($_POST['payNew'])){
    if (checkDuplicateEntries("bank", "card_number_1", $cardNumber1, $db)){
        $result = flashMessage("card_number is already taken, please try another one");
    }}
    elseif(isset($_POST['saveCard']) && $status == "Active"){
    //create SQL insert statement
    $sqlInsertBank = "INSERT INTO bank (bank_name, card_type, card_number_1, card_number_2, card_number_3, card_number_4, valid_date, status, user_id)
                VALUES (?,?,?,?,?,?,?,?,?)";
                
    $statement1 = $db->prepare($sqlInsertBank);
    
    //add the data into the database
    $statement1->execute(array($bankName, $transaction_type, $cardNumber1, $cardNumber2, $cardNumber3, $cardNumber4, $expiry, $status, $user_id));
    }else{
        $result =  flashMessage("Card Not Active!, Please Contact Your Bank.");
    }

    if($status == "Active" || isset($_POST['payEwallet']) || isset($_POST['payOnline']) || isset($_POST['exitingCard'])){
    //create SQL insert statement
    $sqlInsert = "INSERT INTO transaction (user_id, ticket_id, transaction_date, amount, transaction_type, ticketValid)
                VALUES (?,?,?,?,?,?)";
                
    $statement = $db->prepare($sqlInsert);
    
    //add the data into the database
    $statement->execute(array($user_id, $ticket_id, $date_of_purchase, $price, $transaction_type, $expiration_time));
            
    //check if one new row was created
    if($statement->rowCount() == 1){
     $result =  flashMessage("Hurray! Ticket Successfully Purchased", "Pass");
     redirecTo("student_home");
    }
}else {
    $result =  flashMessage("Card Not Active! Please Contact Your Bank.");
}
        

}catch (PDOException $ex){
                $result =  flashMessage("An error occurred: ".$ex->getMessage());
            }


}
?>
