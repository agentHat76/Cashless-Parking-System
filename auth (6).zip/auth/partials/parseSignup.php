<?php 
//add database connection script
include_once 'resource/Database.php';
include_once 'resource/utilities.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

//process the form
if(isset($_POST['signupBtn'])){
    //initialize an array to store any error message from the form
    $form_errors = array();

    //Form validation
    $required_fields = array('firstname','lastname','studentID','email', 'username', 'password');

    //call the function to check empty field and merge the return data into form_error array
    $form_errors = array_merge($form_errors, check_empty_fields($required_fields));

    //Fields that requires checking for minimum length
    $field_to_check_length = array('username' => 4, 'password' => 6);

    //call the function to check minimum required length and merge the return data into form_error array
    $form_errors = array_merge($form_errors, check_min_length($field_to_check_length));

    //email validation / merge the return data into form_error array
    $form_errors = array_merge($form_errors, check_email($_POST));

    //collect form data and store in variables
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $studentID = $_POST['studentID'];
    $email = $_POST['email'];
    $username = $_POST['username'];
    $password = $_POST['password'];

    // $hashed_firstname = encryptFunction($firstname);
    // $hashed_lastname = encryptFunction($lastname);
    // $hashed_studentID = encryptFunction($studentID);
    // $hashed_username = encryptFunction($username);
    // $hashed_email = encryptFunction($email);


    if (checkDuplicateEntries("users", "email", $email, $db)){
        $result = flashMessage("Email is already taken, please try another one");
    }

    else if (checkDuplicateEntries("users", "username", $username, $db)){
        $result = flashMessage("Username is already taken, please try another one");
    }

    //check if error array is empty, if yes process form data and insert record
    else if(empty($form_errors)){
        
        //hashing the password
        $hashed_password = encryptFunction($password);

        try{

            //create SQL insert statement
            $sqlInsert = "INSERT INTO users (firstname, lastname, studentID, username, email, password, join_date)
                        VALUES (:firstname, :lastname, :studentID, :username, :email, :password, now())";
    
            //use PDO prepared to sanitize data
            $statement = $db->prepare($sqlInsert);
    
            //add the data into the database
            $statement->execute(array(':firstname' => $firstname, ':lastname' => $lastname, ':studentID' => $studentID, ':username' => $username, 'email' => $email, ':password' => $hashed_password));
        
            //check if one new row was created
            if($statement->rowCount() == 1){
                $result =  flashMessage("Registration Successful", "Pass");
                echo "<meta http-equiv='refresh' content='1'>";
            }
    
            } catch (PDOException $ex){
                $result =  flashMessage("An error occurred: ".$ex->getMessage());
            }
    }
    
    else {
        if(count($form_errors) == 1){
            $result =  flashMessage("There was 1 error in the form<br>");
        }else{
            $result =  flashMessage(" There are " .count($form_errors)." error in the form<br>");
        }
    }
} elseif(isset($_POST['addStaffBtn'])){
    //initialize an array to store any error message from the form
    $form_errors = array();

    //Form validation
    $required_fields = array('name','staffID', 'staffDepartment','email', 'password');

    //call the function to check empty field and merge the return data into form_error array
    $form_errors = array_merge($form_errors, check_empty_fields($required_fields));

    //Fields that requires checking for minimum length
    $field_to_check_length = array('staffID' => 4, 'password' => 6);

    //call the function to check minimum required length and merge the return data into form_error array
    $form_errors = array_merge($form_errors, check_min_length($field_to_check_length));

    //email validation / merge the return data into form_error array
    $form_errors = array_merge($form_errors, check_email($_POST));

    //collect form data and store in variables
    $name = $_POST['name'];
    $staffID = $_POST['staffID'];
    $staffDepartment = $_POST['staffDepartment'];
    $email = $_POST['email'];
    $password = $_POST['password'];


    if (checkDuplicateEntries("admin", "email", $email, $db)){
        $result = flashMessage("Email is already taken, please try another one");
    }

    else if (checkDuplicateEntries("admin", "username", $staffID, $db)){
        $result = flashMessage("Staff ID is already taken, please try another one");
    }

    //check if error array is empty, if yes process form data and insert record
    else if(empty($form_errors)){
        
        //hashing the password
        //$hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $hashed_password = encryptFunction($password);
        // $hashed_name = encryptFunction($name);
        // $hashed_staffID = encryptFunction($staffID);
        // $hashed_staffDepartment = encryptFunction($staffDepartment);
        // $hashed_email = encryptFunction($email);


        try{

            //create SQL insert statement
            $sqlInsert = "INSERT INTO admin (name, username, email,department, password, join_date)
                        VALUES (:name, :username, :email, :department, :password, now())";
    
            //use PDO prepared to sanitize data
            $statement = $db->prepare($sqlInsert);
    
            //add the data into the database
            $statement->execute(array(':name' => $name, ':username' => $staffID, 'email' => $email,':department' => $staffDepartment ,':password' => $hashed_password));
        
            //check if one new row was created
            if($statement->rowCount() == 1){
                $result =  flashMessage("Registration Successful", "Pass");
                echo "<meta http-equiv='refresh' content='2'>";

                // $email = $results[0]['staff_email'];
                // $name = $results[0]['staff_name'];
                $subject = "Your Username and Passowrd for CPS for Segi College";
                $message = " Staff Name: ".$name."\r\n Staff Email: ".$email."\r\n Staff Department: ".$staffDepartment."\r\n Username(Staff ID): ".$staffID."\r\n Password: ".$password;
                require "vendor/autoload.php";

                $mail = new PHPMailer(true);
                try {
                $mail->isSMTP();
                $mail->SMTPAuth = true;
                
                $mail->Host = "smtp.gmail.com";
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = 587;
                
                $mail->Username = "marmaa76kr@gmail.com";
                $mail->Password = "gnwgcqwdonrgftdd";
                
                $mail->setFrom('marmaa76kr@gmail.com');
                $mail->addAddress("kkyyscrum23@gmail.com", "QA Coordinator");
                $mail->setFrom('marmaa76kr@gmail.com');
                $mail->addAddress($email, $name);
                // $mail->setFrom('marmaa76kr@gmail.com');
                // $mail->addAddress($email1, $name1);

                
                $mail->Subject = $subject;
                $mail->Body = $message;
                
                $mail->send();
            } catch (Exception $e) {
                $result =  flashMessage("We ran into an error while sending the email: {$mail->ErrorInfo}");
            }
                
            }
    
            } catch (PDOException $ex){
                $result =  flashMessage("An error occurred: ".$ex->getMessage());
            }
    }
    
    else {
        if(count($form_errors) == 1){
            $result =  flashMessage("There was 1 error in the form<br>");
        }else{
            $result =  flashMessage(" There are " .count($form_errors)." error in the form<br>");
        }
    }
}


