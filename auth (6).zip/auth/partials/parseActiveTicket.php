<?php
include_once 'resource/Database.php';
include_once 'resource/utilities.php';
include_once 'resource/session.php';

ini_set('display_errors','Off');
ini_set('error_reporting', E_ALL );
define('WP_DEBUG', false);
define('WP_DEBUG_DISPLAY', false);

if((isset($_SESSION['id']) || isset($_GET['user_identity']))){
   
    $id = $_SESSION['id'];
    

    $sqlQuery = "SELECT * FROM transaction WHERE user_id = :id";
    $statement = $db->prepare($sqlQuery);
    $statement->execute(array(':id' => $id));

    while($rs = $statement->fetch()){
        $Transaction_id =$rs['Transaction_id'];
        $transaction_date = $rs['transaction_date'];
        $expiration_day = $rs['ticketValid'];
        //$email = $rs['email'];
        //$date_joined = strftime("%b %d, %Y", strtotime($rs["join_date"]));
    }

    $timestamp = strtotime($expiration_day);
    $validUntil = date("d-m-Y", $timestamp);
    $ticket_id = $Transaction_id;
    $date_of_purchase = $transaction_date;



    $encode_id = base64_encode("encodeuserid{$id}");

    // Generate QR code
    $ticket_info = "transaction_id: $ticket_id\nDate of Purchase: $date_of_purchase\nValid for $validUntil";
    $qr_code = urlencode($ticket_info);

} 