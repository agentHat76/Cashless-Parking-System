<?php 
include_once 'resource/session.php'; 
include_once 'resource/Database.php'; 
include_once 'resource/utilities.php'; 

?>

<!DOCTYPE html>

<head lang="en">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/x-icon" href="uploads/favicon-32x32.png">
    <script src="https://cdn.rawgit.com/davidshimjs/qrcodejs/gh-pages/qrcode.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">

    <link href="resource/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="resource/bootstrap.css" rel="stylesheet">
    <!-- <link href="resource/style.css" rel="stylesheet"> -->


    <title> <?php if(isset($page_title)) echo $page_title ?> </title>
</head>

 <body> <!-- style="background: linear-gradient(to right, #ff8e8e, #ee98ff);"--> 
<header>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
  <div class="container-fluid">
  <img src="uploads/logo.png" class="rounded-circle mr-2" alt="" width="50" height="50">
  <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasDarkNavbar" aria-controls="offcanvasDarkNavbar" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
      
    </button>
    <div class="offcanvas navbar-expand-md navbar-collapse text-center" id="navbarsExampleDefault">
    <a class="navbar-brand" href="index.php" style="font-family: 'Raleway';">CPS Segi College Subang Jaya</a>
   
    <div class="offcanvas offcanvas-end text-bg-dark" tabindex="-1" id="offcanvasDarkNavbar" aria-labelledby="offcanvasDarkNavbarLabel">
      <div class="offcanvas-header">
        <h5 class="offcanvas-title" id="offcanvasDarkNavbarLabel"><a class="navbar-brand" href="admin.php" style="font-family: 'Raleway';">CPS Segi College Subang Jaya</a></h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
      </div>
      <div class="offcanvas-body">
        <ul class="navbar-nav justify-content-end flex-grow-1 pe-3"><i class="text-hide "><?php echo guard();?></i>
        <li class="nav-item">
            <a class="nav-link btn btn-outline-secondary border-0" href="admin.php">Home</a>
          </li>
          <?php if((isset($_SESSION['username']) || isCookieValid($db))): ?>
            <li class="nav-item dropdown ">
          <a class="nav-link dropdown-toggle btn btn-outline-secondary border-0" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            User Page
          </a>
          <ul class="dropdown-menu dropdown-menu-dark">
            <li><a class="dropdown-item"  href="adminUser.php">User's Details</a></li>
            <li><a class="dropdown-item" href="adminTransaction.php">Transaction Details</a></li>
          </ul>
        </li>
        <?php if($_SESSION['department'] === "IT Admin"): ?>
        <li class="nav-item dropdown ">
          <a class="nav-link dropdown-toggle btn btn-outline-secondary border-0" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Staff Page
          </a>
          <ul class="dropdown-menu dropdown-menu-dark">
            <li><a class="dropdown-item"  href="addStaff.php">Add Staff</a></li>
            <li><a class="dropdown-item" href="adminStaffList.php">Staff Details</a></li>
          </ul>
        </li>
        <?php endif ?>
             <li class="nav-item">
                <a class="nav-link btn btn-outline-danger border-0" href="logout.php">Logout</a>
            </li>

          <?php else: ?>
             <li class="nav-item">
                <a class="nav-link btn btn-outline-secondary border-0" href="login.php">Login</a>
            </li>
            <li class="nav-item">
                <a class="nav-link btn btn-outline-secondary border-0" href="Signup.php">Sign up</a>
            </li>
            <li class="nav-item">
                <a class="nav-link btn btn-outline-info border-0" href="AdminLogin.php">Admin</a>
            </li>

            <?php endif ?>

      </div>
    </div>
  </div>
</nav>
    <div class="mb-5"></div>
</header>