<?php
$page_title = "Admin Staff List Page";
include_once 'partials/adminHeader.php';
include_once 'resource/utilities.php';
include_once 'partials/parseAdminLogin.php';
if(isset($_POST['deleteButton'])){
    $admin_id = $_POST['deleteButton'];
    try{
      $sqlQuery = "DELETE FROM admin WHERE admin_id=:admin_id";
      $statement = $db->prepare($sqlQuery);
      $date = [
          ':admin_id' => $admin_id
      ];
      $sqlQuery_execute = $statement->execute($date);
  
      if($sqlQuery_execute)
      {
        $resultMessage = flashMessage("Deleted Successfully");
        echo "<meta http-equiv='refresh' content='2'>";
      } 
      else 
      {
        $resultMessage = flashMessage("Not Deleted");
        echo "<meta http-equiv='refresh' content='2'>";
      }
  
  
  } catch (PDOException $e) {
      echo $e->getMessage();
  }
  }
?>

<main style="padding-top: 10px;">
<!-- if admin not sign in it show message -->
 <?php if(!isset($_SESSION['username'])): ?> 

<p class="lead">You are currently not signin <a href="adminlogin.php">Login!</a> 

 if admin sign in ready it run below code 

<?php else: ?>

<section class="mt-3 container-fluid">

<div class="card">
    <div class="card-header">
        <h1 class="text-center text-success">Staff  Details</h1>
    </div>
    <div class="card-body table-responsive">
        <table class="table table-bordered">
            <thead>
                <tr class="shadow">
                    <th>ID</th>
                    <th>Name</th>
                    <th>Staff ID</th>
                    <th>Email</th>
                    <th>Join Date</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php

                    $sort_option = "";
                    $thead = "admin_id";
                    if(isset($_GET['sort_alphabet'])){
                        if($_GET['sort_alphabet'] == "a-z")
                        {
                            $thead = "name";
                            $sort_option = "ASC";
                    
                        }
                        elseif($_GET['sort_alphabet'] == "z-a") 
                        {
                            $thead = "name";
                            $sort_option = "DESC";
                        }
                        elseif($_GET['sort_alphabet'] == "") 
                        {
                            $thead = "admin_id";
                            $sort_option = "ASC";
                        }
                    }

                    $query = "SELECT * FROM admin ORDER BY $thead $sort_option";
                    $statement = $db->prepare($query);
                    $statement->execute();

                    $result = $statement->fetchAll(PDO::FETCH_OBJ); //PDO::FETCH_ASSOC
                    if($result){

                        foreach($result as $row)
                        {
                            
                            $date =  date("d/m/Y", strtotime($row->join_date));
                            ?>
                            <tr class="shadow">
                                <td><?= $row->admin_id ?></td>
                                <td><?= $row->name ?></td>
                                <td><?= $row->username ?></td>
                                <td><?= $row->email ?></td>
                                <td><?= $date?></td>
                                <td>
                                <?php if($row->username  === "admin"): ?>
                                    <a class="d-sm-inline-block btn btn-sm btn-dark shadow">
                                    <i class="fas fa-trash text-white"></i>
                                    </a>
                               
                                <?php else: ?>
                                <form action="" method="post">
                                  <button type="submit" name="deleteButton" class="btn text-bg-danger shadow" value="<?= $row->admin_id ?>" onclick="return confirm('Are you sure?')"><i class="fas fa-trash text-white"></i></button>
                                </form>
                                <?php endif ?>
                                </td>
                            </tr>
                            <?php

                        }

                    } else {
                        ?>
                        <tr>
                            <td colspan="5">No Record Found</td>
                        </tr>
                        <?php
                    }
                ?>
                
            </tbody>
            <tfoot>
            <div>
            <?php if(isset($resultMessage)) echo $resultMessage; ?>
            <?php if(!empty($form_errors)) echo show_errors($form_errors); ?>
            </div>
            <p style="font-size:large;"><a href="adminUser.php" class="btn btn-secondary mt-3">Back</a></p>
            <form action="" method="GET">
            <div class="input-group mb-2">
                <select name="sort_alphabet" class="form-control">
                    <option value="" <?php if(isset($_GET['sort_alphabet']) && $_GET['sort_alphabet'] == ""){ echo "selected";}?>>--Select Option--</option>
                    <option value="a-z" <?php if(isset($_GET['sort_alphabet']) && $_GET['sort_alphabet'] == "a-z"){ echo "selected";}?>>A-Z (Ascending Order)</option>
                    <option value="z-a" <?php if(isset($_GET['sort_alphabet']) && $_GET['sort_alphabet'] == "z-a"){ echo "selected";}?>>Z_A (Descending Order)</option>
                </select>
                <button type="submit" class="input-group-text btn btn-primary" id="basic-addon2">Sort</button>
            </div>
        </form>
            </tfoot>

        </table>

    </div>
</div>

</section>


    

 <?php endif ?>
</main>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</body>
</html>