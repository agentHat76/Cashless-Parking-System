<?php
$page_title = "Account Page";
include_once 'partials/header.php';
include_once 'partials/parseProfile.php';
?>


<main style="padding-top: 10px;">
    <div>
    <section>
        
        <!-- if not log in it show alert message -->
        <div style="margin-bottom: 25px;"></div>
        <?php if(!isset($_SESSION['username'])): ?>
        <p class="lead">You are not authorized to view this page <a href="login.php">Login</a>
        Not yet a member? <a href="signup.php">Signup</a></p>
        <?php else: ?>

<!-- if log in onto account, it below content             -->
<div class="container mt-3">

<!-- using bootstrap css design card -->
<div class="card mb-2">
<!-- card header -->
  <div class="card-header">
    <ul class="nav nav-tabs card-header-tabs ">
      <li class="nav-item">
        <a class="nav-link active text-bg-primary" aria-current="true" href="#">My Profile</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active" href="bankCard.php">Banks & Cards </a>
      </li>
      <li class="nav-item">
        <a class="nav-link active" href="myTransaction.php">My Purchase</a>
      </li>
    </ul>
  </div>
  <!-- card body -->
  <div class="card-body">
    <!-- my profile content -->
    <div class="card shadow">
<div class="card-header text-bg-primary text-center"><h1>Profile</h1></div>
<div class="card-body d-flex flex-wrap justify-content-center">
    <div class="form-group text-dark mt-2 mr-5 text-center">
    <img src="<?php if(isset($profile_picture)) echo$profile_picture ?>"alt="Avatar" class="img-thumbnail border border-light rounded-5" style="width: 200px;" />
    <h6>Avatar</h6>
    </div>
    <div class="form-group text-dark mt-4">
    <h6>Email</h6>
    <label class="text-dark" name="email" value=""><?php if(isset($email)) echo$email ?></label>
    <hr>
    <h6 class="text-dark">Name</h6>
    <label class="text-dark" name="name" value=""><?php if(isset($name)) echo$name ?></label>
    <hr>
    <h6 class="text-dark ">Date Joined</h6>
    <label class="text-dark" name="name" value=""><?php if(isset($date_joined)) echo$date_joined ?></label>
    <hr>
  <h6 class="text-dark ">Student ID</h6>
  <label type="date" class="text-dark" name="dob" value=""><?php if(isset($studentID)) echo$studentID ?></label>
  <hr>
  </div>
</div>
<!-- card footer -->
<div class="card-footer d-flex flex-wrap justify-content-between">
<a type="submit" name="updatePBtn" class="btn btn-secondary " href="student_home.php">back</a>
<a class="float-end btn btn-outline-primary" href="edit_profile.php?user_identity=<?php if(isset($encode_id)) echo $encode_id; ?>">
                            <span class="glyphicon glyphicon-edit"></span>Edit Profile</a>
</div>
</div>
  </div>
</div>


</div>
            </section>
        <?php endif ?>
    </div>
</main>


<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</body>
</html>