<?php
$page_title = "Sign Up Page";
include_once 'partials/header.php';
include_once 'partials/parseSignup.php';
?>
<main style="padding-top: 50px; padding-bottom: 20px;">
<div class="container d-flex justify-content-center ">
    <section class="col col-lg-7 border rounded-2 p-3 shadow">
        <h2 class="mb-4">Create Your Account</h2>
<div>
<hr class="border border-primary border-3 opacity-75">
</div>


</form>
<div>
<?php if(isset($result)) echo $result; ?>
<?php if(!empty($form_errors)) echo show_errors($form_errors); ?>
</div>

<form action="" method="post">
  <div class="form-group">
    <label for="firstNameField">First Name</label>
    <input type="text" class="form-control" name="firstname" id="firstnameField" aria-describedby="firstnameHelp" placeholder="First Name">
  </div>
  <div class="form-group">
    <label for="lastNameField">Last Name</label>
    <input type="text" class="form-control" name="lastname" id="lastnameField" aria-describedby="lastnameHelp" placeholder="Last Name">
  </div>
  <div class="form-group">
    <label for="studentIDField">Student ID</label>
    <input type="text" class="form-control" name="studentID" id="studentIDField" aria-describedby="firstnameHelp" placeholder="Student ID">
  </div>
    <div class="form-group">
    <label for="emailField">Email</label>
    <input type="text" class="form-control" name="email" id="emailField" aria-describedby="emailHelp" placeholder="Email">
    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
  </div>
  <div class="form-group">
    <label for="usernameField">Username</label>
    <input type="text" class="form-control" name="username" id="usernameField" aria-describedby="usernameHelp" placeholder="Username">
    <small id="usernameHelp" class="form-text text-muted">We'll never share your username with anyone else.</small>
  </div>
  <div class="form-group">
    <label for="passwordField">Password</label>
    <input type="password" class="form-control" name='password' id="passwordField" placeholder="Password"  pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" 
        title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters">
  </div>
  <div class="form-group">
    <label for="passwordField">Confirm Password</label>
    <input type="password" class="form-control" name='confirmPassword' id="confirmPassword" placeholder="Confirm Password">
  </div>
  <button type="reset" class="btn btn-secondary">Clear Form</button>
  <button type="submit" name="signupBtn" class="btn btn-primary float-right">Sign up</button>
</form>
    </section>
</div>
</main>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</body>
</html>

<script>
    var password = document.getElementById("passwordField")
  , confirm_password = document.getElementById("confirmPassword");

function validatePassword(){
  if(password.value != confirm_password.value) {
    confirm_password.setCustomValidity("Passwords Don't Match");
  } else {
    confirm_password.setCustomValidity('');
  }
}

password.onchange = validatePassword;
confirm_password.onkeyup = validatePassword;
</script>