-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 29, 2023 at 12:44 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `register`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(225) NOT NULL,
  `department` varchar(30) NOT NULL,
  `join_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `name`, `username`, `password`, `email`, `department`, `join_date`) VALUES
(1001, 'Krishnan', 'admin', '$2y$10$YCMbpM7mnYg0e/nkcR8IZOkIpzWDIXL3ompRYaaZ7cT0.Qj.h04I2', 'admin@gmail,com', 'IT Admin', '2023-04-27 14:08:52'),
(1003, 'david', 'MRKT123', '$2y$10$WspTvCrqY5zOB/4VDR0gHuRseNfVuCbWV7Oo9672YSH.asEmL1VWu', 'david@gmail.com', 'marketing', '2023-04-27 15:50:22'),
(1005, 'demo', 'FIN1234', '$2y$10$DJddgTaMoO9IKXzpudPMfOXx02CQvbfcrQcj24gXlc5/xVDmEe/wS', 'demo@gmail.com', 'Finance', '2023-04-27 15:00:50'),
(1006, 'Guna', 'MAN1234', '$2y$10$c1nIJz3jIeG91PkUgPO8f.SQhzf3E2cl9Aog8.L3zdyGQtfhxlyAm', 'marmaa76kr@ymail.com', 'Management', '2023-04-27 16:03:47');

-- --------------------------------------------------------

--
-- Table structure for table `bank`
--

CREATE TABLE `bank` (
  `bank_id` int(10) NOT NULL,
  `card_type` varchar(30) NOT NULL,
  `bank_name` varchar(30) NOT NULL,
  `card_number_1` int(4) NOT NULL,
  `card_number_2` int(4) NOT NULL,
  `card_number_3` int(4) NOT NULL,
  `card_number_4` int(4) NOT NULL,
  `valid_date` date NOT NULL,
  `status` varchar(10) NOT NULL,
  `user_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bank`
--

INSERT INTO `bank` (`bank_id`, `card_type`, `bank_name`, `card_number_1`, `card_number_2`, `card_number_3`, `card_number_4`, `valid_date`, `status`, `user_id`) VALUES
(1, 'Credit Card', 'CIMB', 1234, 4567, 7890, 7601, '2026-04-01', 'Active', 1),
(7, 'Credit / Debit Card', 'CIMB BANK', 1235, 1235, 1235, 1235, '2023-01-01', 'No Active', 1),
(8, 'Credit / Debit Card', 'CIMB BANK', 1234, 1234, 1234, 1234, '2023-08-01', 'Active', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ticket`
--

CREATE TABLE `ticket` (
  `ticket_id` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `description` varchar(50) NOT NULL,
  `price` double(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ticket`
--

INSERT INTO `ticket` (`ticket_id`, `Name`, `description`, `price`) VALUES
(1, 'Per day', 'valid for one day only', 2.00);

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `Transaction_id` int(11) NOT NULL,
  `user_id` int(10) NOT NULL,
  `ticket_id` int(10) NOT NULL,
  `transaction_date` date NOT NULL,
  `amount` double(10,2) NOT NULL,
  `transaction_type` varchar(20) NOT NULL,
  `ticketValid` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`Transaction_id`, `user_id`, `ticket_id`, `transaction_date`, `amount`, `transaction_type`, `ticketValid`) VALUES
(1004, 1, 1, '2023-03-21', 2.00, 'card', '2023-03-22'),
(1005, 2, 1, '2023-03-21', 2.00, 'card', '2023-03-22'),
(1006, 1, 1, '2023-03-21', 2.00, 'card', '2023-03-22'),
(1007, 1, 1, '2023-03-21', 2.00, 'card', '2023-03-22'),
(1008, 1, 1, '2023-03-21', 2.00, 'card', '2023-03-22'),
(1009, 1, 1, '2023-03-21', 2.00, 'card', '2023-03-22'),
(1010, 1, 1, '2023-03-21', 2.00, 'card', '2023-03-22'),
(1011, 1, 1, '2023-03-21', 2.00, 'card', '2023-03-20'),
(1012, 2, 1, '2023-03-21', 2.00, 'card', '2023-03-22'),
(1013, 2, 1, '2023-03-21', 2.00, 'card', '2023-03-22'),
(1014, 2, 1, '2023-03-21', 2.00, 'card', '2023-03-22'),
(1015, 2, 1, '2023-03-21', 2.00, 'card', '2023-03-22'),
(1016, 2, 1, '2023-03-21', 2.00, 'card', '2023-03-22'),
(1017, 1, 1, '2023-03-21', 2.00, 'card', '2023-03-20'),
(1018, 1, 1, '2023-03-21', 2.00, 'card', '2023-03-19'),
(1019, 1, 1, '2023-03-21', 2.00, 'card', '2023-03-21'),
(1020, 13, 1, '2023-03-21', 2.00, 'card', '2023-03-21'),
(1022, 14, 1, '2023-03-21', 2.00, 'card', '2023-03-21'),
(1023, 14, 1, '2023-03-21', 2.00, 'card', '2023-03-21'),
(1024, 1, 1, '2023-03-21', 2.00, 'card', '2023-03-21'),
(1025, 1, 1, '2023-03-22', 2.00, 'card', '2023-03-22'),
(1026, 1, 1, '2023-03-28', 2.00, 'card', '2023-03-28'),
(1027, 1, 1, '2023-03-30', 2.00, 'card', '2023-03-30'),
(1028, 1, 1, '2023-03-30', 2.00, 'Credit', '2023-03-30'),
(1029, 1, 1, '2023-03-30', 2.00, 'E-Wall', '2023-03-30'),
(1030, 1, 1, '2023-03-30', 2.00, 'Credit', '2023-03-30'),
(1031, 1, 1, '2023-03-30', 2.00, 'E-Wall', '2023-03-30'),
(1032, 14, 1, '2023-03-30', 2.00, 'Online Banking', '2023-03-30'),
(1033, 1, 1, '2023-03-31', 2.00, 'Credit Card', '2023-03-31'),
(1034, 1, 1, '2023-04-01', 2.00, 'Online Banking', '2023-04-01'),
(1035, 1, 1, '2023-04-01', 2.00, 'Debit Card', '2023-04-01'),
(1036, 1, 1, '2023-04-13', 2.00, 'Online Banking', '2023-04-13'),
(1037, 1, 1, '2023-04-15', 2.00, 'Debit Card', '2023-04-15'),
(1038, 15, 1, '2023-04-15', 2.00, 'Online Banking', '2023-04-15'),
(1039, 1, 1, '2023-04-26', 2.00, 'Online Banking', '2023-04-26'),
(1040, 1, 1, '2023-04-27', 2.00, 'Debit Card', '2023-04-27'),
(1041, 1, 1, '2023-04-27', 2.00, 'Debit Card', '2023-04-27'),
(1042, 1, 1, '2023-04-27', 2.00, 'Credit Card', '2023-04-27'),
(1043, 1, 1, '2023-04-27', 2.00, 'Credit Card', '2023-04-27'),
(1044, 1, 1, '2023-04-28', 2.00, 'Credit Card', '2023-04-28'),
(1045, 1, 1, '2023-04-28', 2.00, 'Credit Card', '2023-04-28'),
(1046, 1, 1, '2023-04-28', 2.00, 'Credit Card', '2023-04-28'),
(1047, 1, 1, '2023-04-28', 2.00, 'Credit Card', '2023-04-28'),
(1048, 1, 1, '2023-04-28', 2.00, 'Credit Card', '2023-04-28'),
(1049, 1, 1, '2023-04-28', 2.00, 'Credit Card', '2023-04-28'),
(1050, 1, 1, '2023-04-28', 2.00, 'Credit Card', '2023-04-28'),
(1051, 1, 1, '2023-04-28', 2.00, 'Credit Card', '2023-04-28'),
(1052, 1, 1, '2023-04-28', 2.00, 'Credit Card', '2023-04-28'),
(1053, 1, 1, '2023-04-28', 2.00, 'Credit Card', '2023-04-28'),
(1054, 1, 1, '2023-04-28', 2.00, 'Credit Card', '2023-04-28'),
(1055, 1, 1, '2023-04-28', 2.00, 'Credit Card', '2023-04-28'),
(1056, 1, 1, '2023-04-28', 2.00, 'Credit Card', '2023-04-28'),
(1057, 1, 1, '2023-04-28', 2.00, 'Credit Card', '2023-04-28'),
(1058, 1, 1, '2023-04-28', 2.00, 'Credit Card', '2023-04-28'),
(1059, 1, 1, '2023-04-28', 2.00, 'Credit / Debit Card', '2023-04-28'),
(1060, 1, 1, '2023-04-28', 2.00, 'Online Banking', '2023-04-28'),
(1061, 1, 1, '2023-04-28', 2.00, 'Online Banking', '2023-04-28'),
(1062, 1, 1, '2023-04-28', 2.00, 'paymentMethod', '2023-04-28'),
(1063, 1, 1, '2023-04-28', 2.00, 'Credit / Debit Card', '2023-04-28'),
(1064, 1, 1, '2023-04-28', 2.00, 'Credit / Debit Card', '2023-04-28'),
(1065, 1, 1, '2023-04-28', 2.00, 'Credit / Debit Card', '2023-04-28'),
(1066, 1, 1, '2023-04-28', 2.00, 'ONLINE_BANKING', '2023-04-28'),
(1067, 1, 1, '2023-04-28', 2.00, 'Credit / Debit Card', '2023-04-28'),
(1068, 1, 1, '2023-04-28', 2.00, 'ONLINE_BANKING', '2023-04-28'),
(1069, 1, 1, '2023-04-28', 2.00, 'Credit / Debit Card', '2023-04-28'),
(1070, 1, 1, '2023-04-28', 2.00, 'Credit / Debit Card', '2023-04-28'),
(1071, 1, 1, '2023-04-28', 2.00, 'Credit / Debit Card', '2023-04-28'),
(1072, 1, 1, '2023-04-28', 2.00, 'Credit / Debit Card', '2023-04-28'),
(1073, 1, 1, '2023-04-28', 2.00, 'Credit / Debit Card', '2023-04-28'),
(1074, 1, 1, '2023-04-28', 2.00, 'Credit / Debit Card', '2023-04-28'),
(1075, 1, 1, '2023-04-28', 2.00, 'Credit / Debit Card', '2023-04-28'),
(1076, 1, 1, '2023-04-28', 2.00, 'Credit / Debit Card', '2023-04-28'),
(1077, 1, 1, '2023-04-28', 2.00, 'Credit / Debit Card', '2023-04-28'),
(1078, 1, 1, '2023-04-28', 2.00, 'PayPal', '2023-04-28'),
(1079, 1, 1, '2023-04-28', 2.00, 'ONLINE_BANKING', '2023-04-28'),
(1080, 1, 1, '2023-04-28', 2.00, 'Touch \'n Go eWallet', '2023-04-28'),
(1081, 1, 1, '2023-04-28', 2.00, 'Credit / Debit Card', '2023-04-28'),
(1082, 1, 1, '2023-04-28', 2.00, 'ONLINE_BANKING', '2023-04-28');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(6) UNSIGNED NOT NULL,
  `username` varchar(30) NOT NULL,
  `firstname` varchar(30) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `join_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `lastname` varchar(30) NOT NULL,
  `studentID` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `firstname`, `password`, `email`, `join_date`, `lastname`, `studentID`) VALUES
(1, 'admin', 'Krishnan', '$2y$10$YCMbpM7mnYg0e/nkcR8IZOkIpzWDIXL3ompRYaaZ7cT0.Qj.h04I2', 'marmaa76kr@gmail.com', '2023-03-21 04:22:29', 'Sinnasamy', 'SCSJ0018581'),
(2, 'demo001', 'demo', '$2y$10$YCMbpM7mnYg0e/nkcR8IZOkIpzWDIXL3ompRYaaZ7cT0.Qj.h04I2', 'demo001@gmail.com', '2023-04-27 17:33:50', '001', 'demo001s'),
(13, 'demo003', 'demo', '$2y$10$WpkxkRvFzIXAwmoMu3XQqO1jFbmjPwmaYtpUb91cw6GDI4U8jxiTC', 'demo003@gmail.com', '2023-03-21 08:47:05', '003', 'demo003'),
(14, 'demo002', 'demo', '$2y$10$3zkfsVKbZsjZ3E1AS7GUXeTf.6oG6rcaoND1bk8EKi4B/lQ/0UC9a', 'demo002@gmail.com', '2023-03-21 09:04:11', '002', 'demo002'),
(16, 'demo004', 'Demo', '$2y$10$Upjy2SWtAj.SkPFitO/Wn.MqHAHbh33vZ4qcJFbcanbn7PGUha7Rq', 'demo004@gmail.com', '2023-04-28 19:56:16', '004', 'demo004'),
(17, 'demo005', 'Demo', '$2y$10$uT0K7vUVMgZMdGQHM71ooeMsAIDUWNpmcz5QNWNrM.PI5AR5cNUcO', 'demo005@gmail.com', '2023-04-28 19:59:56', '005', 'demo005'),
(18, 'demo006', 'demo', '$2y$10$BBeBIZZqRg8ksrjXUMqHCevYbS5Qo1jA13TtZ4f1aRP49Zu8RXtwG', 'demo006@gmail.com', '2023-04-28 20:05:08', '006', 'demo006'),
(19, 'demo007', 'demo', '$2y$10$l0F79KEuPOSAEpT2tU1B4Op95d.E.L2rx0sRDPrAV3C.Qqd0pgqKq', 'demo007@gmail.com', '2023-04-28 20:06:24', '007', 'demo007');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `bank`
--
ALTER TABLE `bank`
  ADD PRIMARY KEY (`bank_id`);

--
-- Indexes for table `ticket`
--
ALTER TABLE `ticket`
  ADD PRIMARY KEY (`ticket_id`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`Transaction_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1017;

--
-- AUTO_INCREMENT for table `bank`
--
ALTER TABLE `bank`
  MODIFY `bank_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `ticket`
--
ALTER TABLE `ticket`
  MODIFY `ticket_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `transaction`
--
ALTER TABLE `transaction`
  MODIFY `Transaction_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1083;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
