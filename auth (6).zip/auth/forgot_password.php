
<?php
$page_title = "Fassword Reset Page";
include_once 'partials/header.php';
include_once 'partials/parseForgotPassword.php';
?>
<main style="padding: 70px;">
<div class="container">
    <section class="col col-lg-7">
        <h2>Password Reset</h2>
<div>
<?php if(isset($result)) echo $result; ?>
<?php if(!empty($form_errors)) echo show_errors($form_errors); ?>
</div>
<div class="clearfix"></div>

</form>

<form action="" method="post">
    <div class="form-group">
    <label for="emailField">Email</label>
    <input type="text" class="form-control" name="email" id="emailField" aria-describedby="emailHelp" placeholder="Email">
  </div>
  <div class="form-group">
    <label for="passwordField">New Password</label>
    <input type="password" class="form-control" name='new_password' id="passwordField" placeholder="Password">
  </div>
  <div class="form-group">
    <label for="passwordField">Confirm Password</label>
    <input type="password" class="form-control" name='confirm_password' id="passwordField" placeholder="Password">
  </div>
  
  <button type="submit" name="passwordResetBtn" class="btn btn-primary">Reset Password</button>
</form>
    </section>
</div>
</main>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</body>
</html>