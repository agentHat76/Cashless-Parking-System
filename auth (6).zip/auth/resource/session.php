<?php 

session_start();

?>