<?php
/**
 * @param $required_fields_array, n array containing the list of all required fields
 * @return array, containing all errors
 */

 function check_empty_fields($required_fields_array){
    //initialize an array to store error messages
    $form_errors = array();

    //loop through the required array and popular the form error array
    foreach($required_fields_array as $name_of_fields){
        if(!isset($_POST[$name_of_fields])  || $_POST[$name_of_fields] == null){
            $form_errors[] = $name_of_fields." is a required field";
        }
    }

    return $form_errors;
 }
 
 /**
  * @param $fields_to_check_length, an array containing the name of fields
  * for which we want to check min required lenght e.g array('username' => 4, 'email' => 12)
  * @return array, containing all errors
  */

  function check_min_length($fields_to_check_length){
    //initilize an array to store error message
    $form_error = array();

    foreach($fields_to_check_length as $name_of_fields => $minium_lenght_required){
       if(strlen(trim($_POST[$name_of_fields])) < $minium_lenght_required){
        $form_error[] = $name_of_fields." is too short, must be {$minium_lenght_required} characters long";
       }
    }

    return $form_error;
  }

  /**
   * @param $data, store a key/ value pair array where key is the name of the form control
   * in the case 'email' and value is the input entered by the  user
   * @return array, containing email error
   */

   function check_email($data){
    //initialize an array to store error messages
    $form_errors = array();
    $key = 'email';
    //check if the key email exits in data array
    if(array_key_exists($key, $data)){

        //check if the email field has a value
        if($_POST[$key] != null){

            //Remove all illegal characters from email
            $key = filter_var($key, FILTER_SANITIZE_EMAIL);

            //check if input is a valid email address
            if(filter_var($_POST[$key], FILTER_VALIDATE_EMAIL) == false){
                $form_errors[] = $key." is not a valid email address";
            }
        }
    }

    return $form_errors;
   }

   /**
    * @param $form_errors_array, the array holding all
    * errors which we want to loop through
    * @return string, list containing all error messages
    */

    function show_errors($form_errors_array){
        $errors = "<p><ul style='color: red;'>";

        //loop through error array and display all item in a list
        foreach($form_errors_array as $the_error){
            $errors .= "<li>{$the_error}</li>";
        }
        $errors .= "</ul></p>";
        return $errors;

    }
    
function flashMessage($message, $passOrFail = "Fail"){
    if($passOrFail === "Pass"){
        $data = "<h5 class='border border-2 text-bg-success rounded-3 opacity-75 p-4'>{$message}</h5>";

    }else {
        $data =  "<h5 class='border border-2 text-bg-danger rounded-3 opacity-75 p-4'>{$message}</h5>";

    }

    return $data;
}

function redirecTo($page){
    header("Location: {$page}.php");
}

function checkDuplicateEntries($table, $column_name, $value, $db){
    try{
        $sqlQuery = "SELECT * FROM " . $table . " WHERE " . $column_name . " = :value";
        $statement = $db->prepare($sqlQuery);
        $statement->execute(array(':value' => $value));

        if($row = $statement->fetch()){
            return true;
        }
        return false;

    } catch(PDOException $e){
        //handle exception
        echo $e->getMessage();
    }
}


/**
 * @param $user_id
 */

 function rememberMe($id) {
    $salt = bin2hex(random_bytes(32));
    $encryptCookieData = base64_encode($salt . $id);
    // Cookie set to expire in 1 day
    $expiry = time() + 60 * 60 * 24;
    $path = '/';
    setcookie("rememberUserCookie", $encryptCookieData, $expiry, $path);
}


/**
 * checked if the cookie used is same with the encrypted cookie
 * @param $db, database connection link
 * @return bool, true if the user cookie is valid
 */

 function isCookieValid($db){
    $isValid = false;

    if (isset($_COOKIE['rememberUserCookie'])){
        /**
         * Decode cookies and extract user ID
         */

         $decryptCookieData = base64_encode($_COOKIE['rememberUserCookie']);
         $user_id = explode("UaQteh5i4y3dntstemYODEC", $decryptCookieData);
         $userID = $user_id[1];

         /**
          * check if id retrieved from the cookie exist in the database
          */
          $sqlQuery = "SELECT * FROM users WHERE id=:id";
          $statement = $db->prepare($sqlQuery);
          $statement->execute(array(':id' => $userID));

          if($row = $statement->fetch()){
            $id = $row['id'];
            $username = $row['username'];

            /**
             * create the user session variable
             */
            $_SESSION['id'] = $id;
            $_SESSION['username'] = $username;
            $isValid = true;

          }else {
            /**
             * cookie ID is invalid destroy session and Logout user
             */
            $isValid = false;
            signout();
          }
    }
    return $isValid;
 }

 function signout(){
    unset($_SESSION['username']);
    unset($_SESSION['id']);

    if(isset($_COOKIE['rememberUserCookie'])){
        unset($_COOKIE['rememberUSerCookie']);
        setcookie('rememberUserCookie', null, -1, '/');
    }
    session_destroy();
    session_regenerate_id(true);
    redirecTo('index');
 }

//  function guard(){
//     $isValid = true;
//     $inactive = 60 * 4; //4mins
//     $fingerprint = md5($_SERVER["REMOTE_ADDR"].$_SERVER['HTTP_USER_AGENT']);

//     if((isset($_SESSION['fingerprint']) &&$_SESSION['fingerprint'] != $fingerprint)){
//         $isValid = false;
//         signout();
//     }else if((isset($_SESSION['last_active']) && (time() - $_SESSION['last_active']) > $inactive) && $_SESSION['username']){
//         $isValid = false;
//         signout();
//     }else{
//         $_SESSION['last_active'] = time();
//     }

//     return $isValid;
// }

function guard(){
    session_start();
    $isValid = true;
    $inactive = 60 * 4; //4mins
    $fingerprint = md5($_SERVER["REMOTE_ADDR"].$_SERVER['HTTP_USER_AGENT']);

    if(isset($_SESSION['fingerprint']) && $_SESSION['fingerprint'] != $fingerprint){
        $isValid = false;
        // call signout() function or use appropriate code here
    } else if(isset($_SESSION['last_active']) && (time() - $_SESSION['last_active']) > $inactive && isset($_SESSION['username'])) {
        $isValid = false;
        // call signout() function or use appropriate code here
    } else {
        $_SESSION['last_active'] = time();
    }

    return $isValid;
}


function isValidImage($file){
    $form_error = array();


    //split file name into an array using the dot (.)
    $part = explode(".", $file);

    //target the last element in the array
    $extension = end($part);

    switch(strtolower($extension)){
        case 'jpg':
        case 'gif':
        case 'bmp':
        case 'png':
        
        return $form_error;
    }

    $form_error[] = $extension." is not a valid image extension";
    return $form_error;
}

function uploadAvatar($username){
    $isImageMoved = false;

    //File in the temp location
    if($_FILES['fileAvatar']['tmp_name']){
        $temp_file = $_FILES['fileAvatar']['tmp_name'];
        $ds = DIRECTORY_SEPARATOR; // uploads/
        $avatar_name = $username.".jpg";

        $path = "uploads".$ds.$avatar_name; //uploads/demo.jpg

        if(move_uploaded_file($temp_file, $path)){
            $isImageMoved = true;
        }

    }

    return $isImageMoved;
}

function encryptFunction($data){
    // Store the cipher method
    $ciphering = "AES-256-CBC";
    // Use OpenSSl Encryption method
    $iv_length = openssl_cipher_iv_length($ciphering);
    $iv = openssl_random_pseudo_bytes($iv_length);
    $options = 0;
    $encryption_iv = '1234567891011121';
    // Store the encryption key
    $encryption_key = base64_decode("G0HPTE61KCQ+CYn3voqMlFnXEtpaow6gYDqaaGSVzuE=");
    // Use openssl_encrypt() function to encrypt the data
    $encryption = openssl_encrypt($data, $ciphering,
                $encryption_key, $options, $iv);
    
    return base64_encode($iv . $encryption);
    }
    
    function decryptFunction($data){
    // Store the cipher method
    $ciphering = "AES-256-CBC";
    // Use OpenSSl Encryption method
    $data = base64_decode($data);
    $iv_length = openssl_cipher_iv_length($ciphering);
    $iv = substr($data, 0, $iv_length);
    $encryption = substr($data, $iv_length);
    $options = 0;
    $decryption_iv = '1234567891011121';
    // Store the decryption key
    $decryption_key = base64_decode("G0HPTE61KCQ+CYn3voqMlFnXEtpaow6gYDqaaGSVzuE=");  
    // Use openssl_decrypt() function to decrypt the data
    $decryption=openssl_decrypt ($encryption, $ciphering, 
            $decryption_key, $options, $iv); 
    if(isset($decryption)){ 
    return $decryption; 
    } else {return "Empty";}  
    }
