const userData = {
    name: "John Smith",
    email: "john.smith@example.com",
    phone: "+1-123-456-7890",
  };
  
  const qrCode = new QRCode(document.getElementById("qrcode"), {
    text: JSON.stringify(userData),
    width: 256,
    height: 256,
  });
  
  qrCode.makeCode(JSON.stringify(userData));
  