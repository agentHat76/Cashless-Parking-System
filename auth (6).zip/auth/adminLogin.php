
<?php
$page_title = "Admin Login Page";
include_once 'partials/adminHeader.php';
include_once 'partials/parseAdminLogin.php';

?>
<main style="padding-top: 70px; padding-bottom: 20px;">
<div class="container d-flex justify-content-center">
    <section class="col col-lg-7 border rounded-2 p-4 shadow">
    <h2 class="mb-3">Login as an Admin User</h2>
<div>
<hr class="border border-primary border-3 opacity-75">
<?php if(isset($result)) echo $result; ?>
<?php if(!empty($form_errors)) echo show_errors($form_errors); ?>
</div>
<div class="clearfix"></div>

</form>

<form action="" method="post">
  <div class="form-group">
    <label for="usernameField">Username</label>
    <input type="text" class="form-control" name="username" id="usernameField" aria-describedby="usernameHelp" placeholder="Username">
  </div>
  <div class="form-group">
    <label for="passwordField">Password</label>
    <input type="password" class="form-control" name='password' id="passwordField" placeholder="Password">
  </div>
  <div class="form-group form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1" name="remember" value="yes">
    <label class="form-check-label" for="exampleCheck1">Remember Me</label>
  </div>
  <div class="form-group">
  </div>

  <button type="submit" name='loginBtn' class="btn btn-primary float-right">Sign in</button>
</form>
    </section>
</div>
</main>


<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>