
<?php
									include_once("resource/Database.php");
									

									require('fpdf_data/fpdf.php');
									

									try {
									//code for print data
                                    $query = "SELECT * FROM Transaction INNER JOIN users ON transaction.user_id = users.id";
                                    $statement = $db->prepare($query);
                                    $statement->execute();
									$results=$statement->fetchAll(PDO::FETCH_OBJ);

                                    $pdf = new FPDF();
									$pdf->AddPage();
                                    // code for print Heading of tables
									$pdf->SetFont('Arial','B',12);	

									if($results)
									{
                                        $pdf->Cell(20,10,"ID",1);
                                            $pdf->Cell(70,10,"Full Name",1);
                                            $pdf->Cell(20,10,"Amount",1);
                                            $pdf->Cell(40,10,"transaction",1);
                                            $pdf->Cell(30,10,"Date" ,1);
                                            $pdf->Ln();

										foreach($results as $row) {
                                            $id = $row->Transaction_id;
											$name = $row->firstname . ' ' .$row->lastname;
                                            $amount = $row->amount;
                                            $typeTRAN = $row->transaction_type;
                                            $date =  date("d/m/Y", strtotime($row->transaction_date));
                                            $pdf->Cell(20,10,$id,1);
                                            $pdf->Cell(70,10,$name,1);
                                            $pdf->Cell(20,10,$amount,1);
                                            $pdf->Cell(40,10,$typeTRAN,1);
                                            $pdf->Cell(30,10,$date ,1);
                                            $pdf->Ln();

										} 
									}
									$pdf->Output("transaction_report.pdf", "D");
                                }
                                catch(PDOException $ex) {
                                    echo "An error occurred: ".$ex->getMessage();
                                }
									?>
								