<?php
$page_title = "Admin User List Page";
include_once 'partials/adminHeader.php';
include_once 'resource/utilities.php';
include_once 'partials/parseAdminLogin.php';

if(isset($_POST['deleteButton'])){
    $id = $_POST['deleteButton'];
    try{
      $sqlQuery = "DELETE FROM users WHERE id=:id";
      $statement = $db->prepare($sqlQuery);
      $sqlQuery_execute = $statement->execute(array(':id' => $id));
  
      if($sqlQuery_execute)
      {
        $resultMessage = flashMessage("Deleted Successfully");
        echo "<meta http-equiv='refresh' content='2'>";
      } 
      else 
      {
        $resultMessage = flashMessage("Not Deleted");
        echo "<meta http-equiv='refresh' content='2'>";
      }
  
  
  } catch (PDOException $e) {
      echo $e->getMessage();
  }
  }

?>

<main style="padding-top: 10px;">
<!-- if admin not sign in it show message -->
 <?php if(!isset($_SESSION['username'])): ?> 

<p class="lead">You are currently not signin <a href="adminlogin.php">Login!</a> 

 if admin sign in ready it run below code 

<?php else: ?>

<section class="mt-3 container-fluid">

<div class="card">
    <div class="card-header">
        <h1 class="text-center text-primary ">User's  Details</h1>
    </div>
    <div class="card-body table-responsive table-wrap">
        <table class="table table-bordered tab">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Full Name</th>
                    <th>Student ID</th>
                    <th>Email</th>
                    <th>Join Date</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php

                    $sort_option = "";
                    $thead = "id";
                    if(isset($_GET['sort_alphabet'])){
                        if($_GET['sort_alphabet'] == "a-z")
                        {
                            $thead = "firstname";
                            $sort_option = "ASC";
                    
                        }
                        elseif($_GET['sort_alphabet'] == "z-a") 
                        {
                            $thead = "firstname";
                            $sort_option = "DESC";
                        }
                        elseif($_GET['sort_alphabet'] == "") 
                        {
                            $thead = "id";
                            $sort_option = "ASC";
                        }
                    }

                    if(isset($_GET['keyword'])){
                        $keyword= $_GET['keyword'];
                        
                        $query = "SELECT * FROM users 
                        WHERE firstname LIKE :keyword
                        ORDER BY $thead $sort_option";
                        $statement = $db->prepare($query);
                        $statement->bindValue(':keyword','%'.$keyword.'%');
                        $statement->execute();
                    }else {

                    $query = "SELECT * FROM users ORDER BY $thead $sort_option";
                    $statement = $db->prepare($query);
                    $statement->execute();
                    }

                    $result = $statement->fetchAll(PDO::FETCH_OBJ); //PDO::FETCH_ASSOC
                    if($result){

                        foreach($result as $row)
                        {
                            $name = $row->firstname . ' ' .$row->lastname;
                            $date =  date("d/m/Y", strtotime($row->join_date));
                            ?>
                            <tr>
                                <td><?= $row->id ?></td>
                                <td><?= $name ?></td>
                                <td><?= $row->studentID ?></td>
                                <td><?= $row->email ?></td>
                                <td><?= $date?></td>
                                <td>
                                    <?php if($_SESSION['department'] === "IT Admin"): ?>

                                                <form action="" method="post">
                                                 <button type="submit" name="deleteButton" class="btn text-bg-danger shadow" value="<?= $row->id ?>" onclick="return confirm('Are you sure?')"><i class="fas fa-trash text-white"></i></button>
                                                <form>

                                                <?php else: ?>

                                                <a class="d-sm-inline-block btn btn-sm btn-dark shadow-sm" data-toggle="modal" data-target="#deleteModal">
                                                    <i class="fas fa-trash text-white"></i>
                                                </a>
                                                <?php endif ?>
                                            </td>
                            </tr>
                            <?php

                        }

                    } else {
                        ?>
                        <tr>
                            <td colspan="5">No Record Found</td>
                        </tr>
                        <?php
                    }
                ?>
                
            </tbody>
            <tfoot>
            <div class="d-sm-flex align-items-center justify-content-between mb-3">
            <p style="font-size:large;"><a href="adminUser.php" class="btn btn-secondary mt-3 mr-2">Back</a></p>
            <div class="d-sm-inline-block form-inline mr-auto my-2 my-md-0 mw-100 idealist-search">
                            <form action="" method="GET">
                            <div class="form-group">
                                <input type="text" class="form-control bg-white border-1 small" placeholder="Search by Name" aria-label="Search" aria-describedby="basic-addon2" name="keyword" value="<?php if(isset($_GET['keyword'])) {echo $_GET['keyword'];} ?>">
                                <div class="input-group-append">
                                    <button type="submit" class="btn btn-secondary" type="button">
                                        <i class="fas fa-search fa-sm"></i>
                                    </button>
                                </div>
                            </div>
            </div>
            <form action="" method="GET">
            <div class="form-group form-inline mb-0 mb-2">
                <select name="sort_alphabet" class="form-control">
                    <option value="" <?php if(isset($_GET['sort_alphabet']) && $_GET['sort_alphabet'] == ""){ echo "selected";}?>>--Select Option--</option>
                    <option value="a-z" <?php if(isset($_GET['sort_alphabet']) && $_GET['sort_alphabet'] == "a-z"){ echo "selected";}?>>A-Z (Ascending Order)</option>
                    <option value="z-a" <?php if(isset($_GET['sort_alphabet']) && $_GET['sort_alphabet'] == "z-a"){ echo "selected";}?>>Z_A (Descending Order)</option>
                </select>
                <button type="submit" class="input-group-text btn btn-primary" id="basic-addon2">Sort</button>
            </div>
                </div>
        </form>
            </tfoot>

        </table>

    </div>
</div>

</section>


    

 <?php endif ?>
</main>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</body>
</html>