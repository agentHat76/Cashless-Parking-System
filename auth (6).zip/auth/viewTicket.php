<?php
$page_title = "Ticket Page";
include_once 'partials/header.php';
include_once 'partials/parseActiveTicket.php';
include_once 'resource/utilities.php';


if(isset($_GET['id'])){
    $url_encoded_id = $_GET['id'];
    $decode_id = base64_decode($url_encoded_id);
    $user_id_array = explode("encodeuserid", $decode_id);
    $id = $user_id_array[1];
    

$transaction_id = $id;

    $sqlQuery = "SELECT * FROM transaction WHERE Transaction_id = :id";
    $statement = $db->prepare($sqlQuery);
    $statement->execute(array(':id' => $transaction_id));
    $result = $statement->fetch(PDO::FETCH_OBJ);

     // Generate QR code
     $ticket_info = "transaction_id: $result->Transaction_id\r\nDate of Purchase: $result->transaction_date\r\nValid for $result->ticketValid";
     $qr_code = urlencode($ticket_info);
     $date =  date("Y/m/d", strtotime($result->transaction_date));
}
?>

<!-- padding for display within layout -->
<main style="padding-top: 70px; padding-left: 35px; padding-bottom: 40px;">

<!-- if user not login, it run below code. display alert message to login or signup -->
<?php if(!isset($_SESSION['username'])): ?>

<p class="lead">You are currently not signin <a href="login.php">Login</a> <br>Not yet a member? <a href="signup.php">Sign up</a> </p>

<!-- if user login successfully, it run below code. display ticket module and purchase module -->
<?php else: ?>

<!-- Ticket module -->
<div class="container-fluid d-sm-flex justify-content-center text-center">
<div class="card rounded-5 p-3 " style="width: 18rem;">
    <h2 class="card-title">Ticket</h2>
    <?php  echo "<img src='https://api.qrserver.com/v1/create-qr-code/?size=256x256&data=$qr_code' class='card-img-top' alt='...''>"; ?>
    <div class="card-body">
    <div id="qrcode" ></div>
    
    <h5 class="card-title">Ticket No.: <?= $result->Transaction_id; ?></h5>
    <p class="card-text"><?= $date?></p>
    <h6 class="card-text">Ticket Price: RM<?= $result->amount ?>.00</h6>
    <p href="#" class="d-block border rounded-2"><?php 
        
        
        if(strtotime($date) === strtotime('today'))
        {
            echo '<span class="text-success">Valid</span>';
        } else {
            echo '<span class="text-danger">No Valid</span>';
        }
        
        ?></p>
        <button class="btn btn-secondary" onclick="history.go(-1)">Back</button>
    </div>
  </div>
    <?php endif ?>
</main>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</body>
</html>