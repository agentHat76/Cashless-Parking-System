<?php
  
// // Store a string into the variable which
// // need to be Encrypted
// $simple_string = "KrishnanIloveYou";
  
// // Display the original string
// echo "Original String: " . $simple_string."<br>";
  
// // Store the cipher method
// $ciphering = "AES-256-CBC";
  
// // Use OpenSSl Encryption method
// $iv_length = openssl_random_pseudo_bytes(openssl_cipher_iv_length($ciphering));
// $options = 0;
  
// // Non-NULL Initialization Vector for encryption
// $encryption_iv = '1234567891011121';
  
// // Store the encryption key
// $encryption_key = base64_decode("G0HPTE61KCQ+CYn3voqMlFnXEtpaow6gYDqaaGSVzuE=");
  
// // Use openssl_encrypt() function to encrypt the data
// $encryption = openssl_encrypt($simple_string, $ciphering,
//             $encryption_key, $options, $iv_length);
  
// // Display the encrypted string
// echo "Encrypted String: " . $encryption . "<br>";
  
// // Non-NULL Initialization Vector for decryption
// $decryption_iv = '1234567891011121';
  
// // Store the decryption key
// $decryption_key = base64_decode("G0HPTE61KCQ+CYn3voqMlFnXEtpaow6gYDqaaGSVzuE=");
  
// // Use openssl_decrypt() function to decrypt the data
// $decryption=openssl_decrypt ($encryption, $ciphering, 
//         $decryption_key, $options, $iv_length);
  
// // Display the decrypted string
// echo "Decrypted String: " . $decryption."<br>";

function encryptFunction($data){
    // Store the cipher method
    $ciphering = "AES-256-CBC";
    // Use OpenSSl Encryption method
    $iv_length = openssl_cipher_iv_length($ciphering);
    $iv = openssl_random_pseudo_bytes($iv_length);
    $options = 0;
    $encryption_iv = '1234567891011121';
    // Store the encryption key
    $encryption_key = base64_decode("G0HPTE61KCQ+CYn3voqMlFnXEtpaow6gYDqaaGSVzuE=");
    // Use openssl_encrypt() function to encrypt the data
    $encryption = openssl_encrypt($data, $ciphering,
                $encryption_key, $options, $iv);
    
    return base64_encode($iv . $encryption);
    }
    
    function decryptFunction($data){
    // Store the cipher method
    $ciphering = "AES-256-CBC";
    // Use OpenSSl Encryption method
    $data = base64_decode($data);
    $iv_length = openssl_cipher_iv_length($ciphering);
    $iv = substr($data, 0, $iv_length);
    $encryption = substr($data, $iv_length);
    $options = 0;
    $decryption_iv = '1234567891011121';
    // Store the decryption key
    $decryption_key = base64_decode("G0HPTE61KCQ+CYn3voqMlFnXEtpaow6gYDqaaGSVzuE=");  
    // Use openssl_decrypt() function to decrypt the data
    $decryption=openssl_decrypt ($encryption, $ciphering, 
            $decryption_key, $options, $iv); 
    if(isset($decryption)){ 
    return $decryption; 
    } else {return "Empty";}  
    }
    echo $data = "Must happy";
    $reslut1 = encryptFunction($data);
    echo "<br>". $reslut1."<br>";
    $result2 = decryptFunction($reslut1);
    print $result2."<br>";
?>