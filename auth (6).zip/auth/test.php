<?php

// Set the expiration time for the ticket to 24 hours from the current time
$expiration_time = time() + 24 * 60 * 60;

// Process the purchase request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate the user input
    $name = htmlspecialchars(trim($_POST['name']));
    $email = htmlspecialchars(trim($_POST['email']));
    $car_model = htmlspecialchars(trim($_POST['car_model']));
    $ticket_price = 50; // Set the ticket price to $50

    // Save the purchase details to the database or a file
    $purchase_details = [
        'name' => $name,
        'email' => $email,
        'car_model' => $car_model,
        'price' => $ticket_price,
        'expiration_time' => $expiration_time
    ];

    // Display a success message to the user
    echo "Thank you for purchasing the car ticket. Your ticket is valid until " . date('Y-m-d H:i:s', $expiration_time);
}

?>
