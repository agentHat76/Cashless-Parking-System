<?php
$page_title = "Edit Profile Page";
include_once 'partials/header.php';
include_once 'partials/parseProfile.php';
?>

<main style="padding: 70px;">
<div class="container ">
    <section class="">
    <h2>Edit Your Account</h2>
<div>
<?php if(isset($result)) echo $result; ?>
<?php if(!empty($form_errors)) echo show_errors($form_errors); ?>
</div>
<div class="clearfix"></div>

<?php if(!isset($_SESSION['username'])): ?>

<p class="lead">You are not authorized to view this page <a href="login.php">Login</a> <br>Not yet a member? <a href="signup.php">Sign up</a> </p>

<?php else: ?>
    <form method="post" action="" enctype="multipart/form-data">
        <div class="form-group">
            <label for="email">Email</label>
            <input type="text" class="form-control" name="email" id="email" value="<?php if(isset($email)) echo $email; ?>">
        </div>
        <div class="form-group">
            <label for="username">Username</label>
            <input type="text" class="form-control" name="username" id="username" value="<?php if(isset($username)) echo $username; ?>">
        </div>
        <div class="form-group">
            <label for="firstname">First Name</label>
            <input type="text" class="form-control" name="firstname" id="firstname" value="<?php if(isset($firstname)) echo $firstname; ?>">
        </div>
        <div class="form-group">
            <label for="lastname">Last Name</label>
            <input type="text" class="form-control" name="lastname" id="lastname" value="<?php if(isset($lastname)) echo $lastname; ?>">
        </div>
        <div class="form-group">
            <label for="fileAvatar">Avatar</label>
            <input type="file" class="form-control" name="fileAvatar" id="fileAvatar">
        </div>
            <input type="hidden" name="hidden_id" value="<?php if(isset($id)) echo $id; ?>">
            <button type="submit" name="updateProfileBtn" class="btn btn-outline-primary float-right">Update Profile</button>
    </form>
    <p style="font-size:large;"><a href="profile.php" class="btn btn-outline-secondary">Back</a></p>
<?php endif ?>
    </section>
    
</main>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>


</body>
</html>
