<?php
$page_title = "Admin Home Page";
include_once 'partials/adminHeader.php';
include_once 'resource/utilities.php';
include_once 'partials/parseAdminLogin.php';  

//total ticket transaction by Month
// Prepare and execute query to get total transactions by month
$stmt = $db->prepare("SELECT COUNT(*) AS total, MONTH(transaction_date) AS month, YEAR(transaction_date) AS year FROM transaction GROUP BY YEAR(transaction_date), MONTH(transaction_date)");
$stmt->execute();
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Create empty arrays for chart labels and data
$months_years = array();
$totals = array();

// Loop through query results and populate arrays
foreach ($rows as $row) {
    $months_years[] = date("F Y", mktime(0, 0, 0, $row['month'], 1, $row['year']));
    $totals[] = $row['total'];
    
}

// Encode arrays as JSON for use in chart
$months_years_json = json_encode($months_years);
$totals_json = json_encode($totals);

//total student join by month
// Prepare and execute query to get total transactions by month
$stmt = $db->prepare("SELECT COUNT(*) AS total, MONTH(join_date) AS month, YEAR(join_date) AS year FROM users GROUP BY YEAR(join_date), MONTH(join_date)");
$stmt->execute();
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Create empty arrays for chart labels and data
$months_years1 = array();
$totals1 = array();

// Loop through query results and populate arrays
foreach ($rows as $row) {
    $months_years1[] = date("F Y", mktime(0, 0, 0, $row['month'], 1, $row['year']));
    $totals1[] = $row['total'];
}

// Encode arrays as JSON for use in chart
$months_years1_json = json_encode($months_years1);
$totals1_json = json_encode($totals1);

?>

<main class="container-fluid" style="padding-top: 70px;">
<!-- if admin not sign in it show message -->
<?php if(!isset($_SESSION['username'])): ?>
  <div class="text-center p1" style="font-family: 'Raleway';">
<h3 class="display-5 mb-2" >Welcome to Car Parking System Using Encrypted</h3>
<h4 class="display-6 text-primary" >Admin Panal</h4>


<h4 class="mt-5">You are currently not <a href="adminLogin.php">signin</a></h4>
</div>

<!-- if admin sign in ready it run below code -->
<?php else: ?>
<div class=" container d-flex justify-content-evenly  flex-wrap border border-light bg-info-subtle shadow">
<h1 class="text-center w-100 mt-5 mb-2">Admin Dashboard</h1>
<!-- This section for total user in the system -->
<Section class="mr-2 mt-3">
  <div class="card shadow ">
    <div class="card-body">
    <h2 class="text-center">Total Subscriber's Count</h2>
    <br>
      <br>
      <h1 class="text-center text-primary  border border-success border-2"><?php 

     $sql = "SELECT COUNT(*) FROM users";
    $res = $db->query($sql);
    $count = $res->fetchColumn();

    print $count." Records";

      ?></h1><br>
      <div class="border border-dark border-0" id="donutchart" style="width: 320px; height: 200px;"></div>
      <br>
      <button class="btn btn-outline-success btn-lg btn-block p-3" onclick="window.location.href = 'adminUser.php';">More Details</button>
    </div>
  </div>
    
</Section>

<!-- This section for total ticket purchased -->
<Section class="mr-2 mt-3 mb-5">
  <div class="card shadow">
    <div class="card-body">
    <h2 class="text-center">Total Ticket Purchased</h2>
    <br>
      <br>
      <h1 class="text-center text-primary border border-success border-2"><?php 
    

     $sql = "SELECT COUNT(*) FROM transaction";
    $res = $db->query($sql);
    $count = $res->fetchColumn();

    print $count." Records";

      ?></h1><br>
      <div class="border border-dark border-0" id="chart_div" style="width: 320px; height: 200px;"></div>
      <br>
      <button class="btn btn-outline-success btn-lg btn-block p-3" onclick="window.location.href = 'adminTransaction.php';">More Details</button>
    </div>
  </div>
    
</Section>
</div>
    

<?php endif ?>
</main>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script src="https://www.gstatic.com/charts/loader.js"></script>
<script>
google.charts.load('current', {'packages':['corechart']});
google.charts.setOnLoadCallback(drawChart);

function drawChart() {
    var months = <?php echo $months_years_json; ?>;
    var totals = <?php echo $totals_json; ?>;

    var data = google.visualization.arrayToDataTable([
        ['Month', 'Total'],
        [months[0], totals[0]],
        [months[1], totals[1]],
        [months[2], totals[2]],
        [months[3], totals[3]],
        [months[4], totals[4]],
        [months[5], totals[5]],
        [months[6], totals[6]],
        [months[7], totals[7]],
        [months[8], totals[8]],
        [months[9], totals[9]],
        [months[10], totals[10]],
        [months[11], totals[11]],
    ]);

    var options = {
        title: 'Total Transactions by Month' ,
        pieHole: 0.5,
        is3D: true,
    };

    var chart = new google.visualization.PieChart(document.getElementById('chart_div'));

    chart.draw(data, options);
}
</script>

<script>
google.charts.load('current', {'packages':['corechart']});
google.charts.setOnLoadCallback(drawChart);

function drawChart() {
    var months = <?php echo $months_years1_json; ?>;
    var totals = <?php echo $totals1_json; ?>;

    var data = google.visualization.arrayToDataTable([
        ['Month', 'Total'],
        [months[0], totals[0]],
        [months[1], totals[1]],
        [months[2], totals[2]],
        [months[3], totals[3]],
        [months[4], totals[4]],
        [months[5], totals[5]],
        [months[6], totals[6]],
        [months[7], totals[7]],
        [months[8], totals[8]],
        [months[9], totals[9]],
        [months[10], totals[10]],
        [months[11], totals[11]],
    ]);

    var options = {
        title: 'Total subscriber by Month' ,
        pieHole: 0.4,
        is3D: true,
    };

    var chart = new google.visualization.PieChart(document.getElementById('donutchart'));

    chart.draw(data, options);
}
</script>


</body>
</html>