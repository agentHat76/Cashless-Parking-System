<?php
$page_title = "FirstPage";
include_once 'partials/header.php';
include_once 'resource/utilities.php';
?>

<main style="padding-top: 70px;">
<div class="container">
<?php if(!isset($_SESSION['username'])): ?>


<div class="text-center p1" style="font-family: 'Raleway';">
<img src="uploads/logo.png" class="rounded-circle" alt="" width="200" height="200">
<h3 class="display-5 ">Welcome to Car Parking System Using Encrypted</h3>
<h4 class="display-6" >for Segi College Subang Jaya</h4>


<h4 class="mt-5">You are currently not <a href="login.php">Login</a> <br>Not yet a member? <a href="signup.php">Sign up</a> </h4>
</div>
<?php else: ?>
<p class="lead">You are logged in as <?php if(isset($_SESSION['username'])) echo $_SESSION['username']; ?> <a href="logout.php">Logout</a></p>
<?php redirecTo('student_home') ?>

<?php endif ?>


</div>
<!--
<?php echo $_SERVER["REMOTE_ADDR"]."<br>". $_SERVER['HTTP_USER_AGENT'];
echo "<br>".time();

if(isset($_SESSION['last_active'])){
echo $_SESSION['last_active'];
};

 ?>
 -->
</main>

<?php include_once 'partials/footer.php'?>
</body>
</html>