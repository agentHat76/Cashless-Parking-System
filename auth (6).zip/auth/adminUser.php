<?php
$page_title = "Admin User Page";
include_once 'partials/adminHeader.php';
include_once 'resource/utilities.php';
include_once 'partials/parseAdminLogin.php';
?>

<main style="padding-top: 5%;">
<!-- if admin not sign in it show message -->
<?php if(!isset($_SESSION['username'])): ?>

<p class="lead">You are currently not signin <a href="adminlogin.php">Login!</a>

<!-- if admin sign in ready it run below code -->

<?php else: ?>

<section class="mt-3 container d-flex justify-content-center  flex-wrap border border-light bg-info-subtle shadow">
<h1 class="text-center w-100 mt-5 mb-5">User's  Count</h1>
<!-- This section for total ticket purchased -->
<Section class="mr-3 mt-3">
  <div class="card flex-fill shadow">
  <div class="card-header"><h2 class="text-center"> On Today Joining</h2></div>
  <div class="card-body">
  <?php 
    

    $sql = "SELECT COUNT(*) FROM users WHERE DATE(join_date) = DATE(now()) and  MONTH(join_date) = MONTH(now())
    and YEAR(join_date) = YEAR(now())";
   $res = $db->query($sql);
   $count = $res->fetchColumn();

      ?>
      <br><br>
      <?php if($count == 0): ?>
      <h1 class="text-center text-danger"> <?php print $count; ?></h1>
      <?php else: ?>
        <h1 class="text-center text-success"><?php print $count; ?> </h1>
      <?php endif ?>
      <br>
      <br>
  </div>
  </div>
      
</Section>

<!-- This section for this month join user in the system -->
<Section class="mr-3 mt-3">
  <div class="card shadow">
  <div class="card-header"><h2 class="text-center">This Month Joining</h2></div>
  <div class="card-body">
  <?php 
    

    $sql = "SELECT COUNT(*) FROM users WHERE MONTH(join_date) = MONTH(now())
    and YEAR(join_date) = YEAR(now())";
   $res = $db->query($sql);
   $count = $res->fetchColumn();

      ?>
      <br><br>
      <?php if($count == 0): ?>
      <h1 class="text-center text-danger"> <?php print $count; ?></h1>
      <?php else: ?>
        <h1 class="text-center text-success"><?php print $count; ?> </h1>
      <?php endif ?>
      <br>
      <br>
  </div>
  </div>
     
</Section>

<!-- This section for this year join user in the system -->
<Section class="mt-3 mb-3">
<div class="card shadow">
  <div class="card-header"><h2 class="text-center">This Year Joining</h2></div>
  <div class="card-body">
  <?php 
    

    $sql = "SELECT COUNT(*) FROM users WHERE YEAR(join_date) = YEAR(now())";
   $res = $db->query($sql);
   $count = $res->fetchColumn();

      ?>
      <br><br>
      <?php if($count == 0): ?>
      <h1 class="text-center text-danger"> <?php print $count; ?></h1>
      <?php else: ?>
        <h1 class="text-center text-success"><?php print $count; ?> </h1>
      <?php endif ?>
      <br>
      <br>
  </div>
  </div>

</Section>
<br>
<br>


<button class="btn btn-primary btn-lg btn-block p-3 mt-5" onclick="window.location.href = 'adminUserList.php';">List of Subscriber</button>
<button class="btn btn-secondary btn-lg btn-block p-3 mb-3" onclick="window.location.href = 'admin.php';">Back</button>
</section>


    

<?php endif ?>
</main>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</body>
</html>